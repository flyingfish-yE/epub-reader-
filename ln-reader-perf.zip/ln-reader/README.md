# 轻小说阅读器（书架 + 阅读器）

## 在 StackBlitz 运行
1. 把本目录里的所有文件（**不要带 `node_modules`、`dist`**）放进一个新的 StackBlitz Node 项目，或用 “Import from zip”。
2. StackBlitz 会自动 `npm install` 并执行 `npm start`（= `vite --host`），Web Preview 打开的就是书架首页。
3. 首次打开书架是空的：点「先载入几本示例书看看」，或点右上角「导入」选择你自己的 `.epub`。

依赖只有两个：`vite`（开发服务器）、`jszip`（解 EPUB）。没有 CDN、没有本地路径。

## 结构
```
index.html            书架（首页）
reader.html           阅读器（原阅读页）
src/shared/
  library.js          书库数据层：IndexedDB（书 + EPUB 文件）+ localStorage（阅读位置）。window.Library
  epub.js             EPUB 解析：OPF / spine / 目录 / 封面 / 章节清洗
  settings.js         主题、字号、插图自动适配、插图设置的读写（两个页面共用）
  samples.js          示例书：现场生成真正的 EPUB
src/shelf/            书架页：shelf.js（含新的 Cover Flow）、shelf.css
src/reader/           阅读页：reader.js（原 script.js + EPUB）、reader.css（原 styles.css + 新增）
public/sample/        示例书里用的插图（就是原阅读器里的测试图）
```
书架 → 阅读器：`Library.openBook(id)` 记录“最近阅读”后跳到 `reader.html?book=<id>`；
阅读器 → 书架：左上角「‹ 书架」。两页之间只通过 `Library` 和 `src/shared/settings.js` 通信。

## 已知限制
- 阅读器只支持上下滚动；设置里的「左右翻页」暂时禁用（原阅读器没有这个功能）。
- EPUB 自带的 CSS 不会被应用（段落、标题、注音 ruby、图片、表格、链接保留）；不支持竖排。
- 备份文件只包含书架信息和进度，不包含 EPUB 文件本体。
