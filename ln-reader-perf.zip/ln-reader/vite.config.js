import { defineConfig } from 'vite';
import { resolve } from 'node:path';

// 多页面：index.html = 书架（首页），reader.html = 阅读器
export default defineConfig({
  server: { host: true, port: 5173, allowedHosts: true },
  preview: { host: true, allowedHosts: true },
  build: {
    rollupOptions: {
      input: {
        shelf: resolve(__dirname, 'index.html'),
        reader: resolve(__dirname, 'reader.html'),
      },
    },
  },
});
