import { Library, onLibraryChange } from '../shared/library.js';
import { sampleBooks, buildSampleEpub } from '../shared/samples.js';
import { readSettings, writeSettings, readAutofit, writeAutofit, readTheme, setTheme as applyThemeSetting, SETTINGS_KEY, AUTOFIT_KEY, THEME_KEY } from '../shared/settings.js';

const $ = (s) => document.querySelector(s);
const flow = $('#flow');
const grid = $('#bookGrid');
const info = $('#flowInfo');
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

// ============ 状态：整个书架只有一个“选中的书”：selectedId ============
let books = [];
let selectedId = null;
let filter = 'all';
let menuBookId = null;
let toastTimer = 0;

const escapeHTML = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const getBook = (id) => books.find((b) => b.id === id) || null;
const getRecent = () => books.filter((b) => b.lastOpenedAt > 0).sort((a, b) => b.lastOpenedAt - a.lastOpenedAt).slice(0, 10);
const pctOf = (b) => Math.round((b.finished ? 1 : b.progress) * 100);
const selectedBook = () => getBook(selectedId);

function showToast(msg, ms = 2300) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), ms);
}

// 轻震动：只在支持的设备上生效（Android Chrome 等）；iOS / 桌面没有 vibrate 或没有马达，静默跳过
function buzz(ms = 10) {
  try {
    if (navigator.vibrate) navigator.vibrate(ms);
  } catch (_) {}
}

// ============ 封面 ============
function placeholder(title, author) {
  return `<div class="cover-placeholder"><div class="p-title">${escapeHTML(title)}</div><div class="rule"></div><div class="p-author">${escapeHTML(author || '未知作者')}</div></div>`;
}
function coverMarkup(b, eager = false) {
  return b.coverThumbUrl
    ? `<img src="${escapeHTML(b.coverThumbUrl)}" alt="${escapeHTML(b.title)}封面" loading="${eager ? 'eager' : 'lazy'}" decoding="async" draggable="false">`
    : placeholder(b.title, b.author);
}
// 封面加载失败：换成统一占位（error 不冒泡，用捕获阶段统一接）
document.addEventListener(
  'error',
  (e) => {
    const img = e.target;
    if (!(img instanceof HTMLImageElement) || !img.closest('.cover, .grid-cover-wrap')) return;
    const b = getBook(img.closest('[data-id]')?.dataset.id);
    const tpl = document.createElement('template');
    tpl.innerHTML = placeholder(b ? b.title : img.alt.replace(/封面$/, ''), b && b.author);
    img.replaceWith(tpl.content.firstElementChild);
  },
  true
);

// ============ 渲染入口 ============
function ensureSelection() {
  const recent = getRecent();
  if (!selectedId || !recent.some((b) => b.id === selectedId)) {
    let remembered = null;
    try {
      remembered = sessionStorage.getItem('lnreader:selected');
    } catch (_) {}
    selectedId = recent.some((b) => b.id === remembered) ? remembered : recent[0]?.id || null;
  }
}
function render() {
  const recent = getRecent();
  $('#recentSection').hidden = recent.length === 0;
  $('#shelfSection').hidden = books.length === 0;
  $('#emptyState').hidden = books.length !== 0;
  ensureSelection();
  buildFlow(recent);
  renderGrid();
}

// ============ Cover Flow ============
// 布局完全由数学公式决定：选中项在容器中心；相邻项按“封面宽度 + 固定间距”排开，天然不会互相遮挡。
const SIDE_SCALE = 0.8; // 相邻封面缩放
const FAR_SCALE = 0.64; // 再远一层
const GAP = 14; // 封面之间的最小空隙（px）
const TILT = 24; // 侧面封面的倾斜角度
let flowItems = []; // [{id, el}]
let flowPos = 0; // 当前显示位置（可为小数，拖动时用）
let metrics = { W: 0, cardW: 160, cardH: 224, d1: 0, d2: 0 };

function computeMetrics() {
  const W = flow.clientWidth || flow.parentElement.clientWidth || 360;
  const maxByHeight = (innerHeight * 0.46) / 1.4; // 矮屏（横屏手机）时限制封面高度
  const cardW = Math.round(Math.max(110, Math.min(W * 0.46, 250, maxByHeight)));
  const cardH = Math.round((cardW * 7) / 5);
  const d1 = (cardW / 2) + GAP + (cardW * SIDE_SCALE) / 2; // 中心 → 相邻
  const d2 = (cardW * SIDE_SCALE) / 2 + GAP + (cardW * FAR_SCALE) / 2; // 相邻 → 再远一层
  metrics = { W, cardW, cardH, d1, d2 };
  flow.style.setProperty('--card-w', cardW + 'px');
  flow.style.setProperty('--card-h', cardH + 'px');
}
// 偏移 k（单位：封面个数，可为小数）→ 位置、缩放、倾斜。分段线性，间距在拖动过程中也保持恒定。
function placeOf(k) {
  const a = Math.abs(k);
  const sign = k < 0 ? -1 : 1;
  const { d1, d2, cardW } = metrics;
  const x = sign * (a <= 1 ? a * d1 : a <= 2 ? d1 + (a - 1) * d2 : d1 + d2 + (a - 2) * d2);
  const scale = a <= 1 ? 1 - (1 - SIDE_SCALE) * a : a <= 2 ? SIDE_SCALE - (SIDE_SCALE - FAR_SCALE) * (a - 1) : FAR_SCALE;
  const rot = reduced ? 0 : -sign * Math.min(a, 1) * TILT;
  const opacity = a <= 2 ? 1 - 0.1 * Math.min(a, 1) : Math.max(0, 1 - (a - 2));
  return { x, scale, rot, opacity, z: 100 - Math.round(a * 10), hidden: a > 3 };
}
function applyPositions() {
  const { W, cardW } = metrics;
  flowItems.forEach(({ el }, i) => {
    const p = placeOf(i - flowPos);
    el.style.transform = `translate3d(${W / 2 - cardW / 2 + p.x}px,-50%,0) rotateY(${p.rot}deg) scale(${p.scale})`;
    el.style.opacity = p.opacity;
    el.style.zIndex = p.z;
    el.classList.toggle('is-hidden', p.hidden);
  });
}
function buildFlow(recent) {
  if (!recent.length) {
    flow.innerHTML = '';
    flowItems = [];
    info.innerHTML = '';
    infoShownId = null;
    return;
  }
  // 复用已有节点：从阅读页回来时封面不会被销毁重建（避免重新解码造成的空白闪烁）
  const old = new Map(flowItems.map((f) => [f.id, f]));
  const sel = Math.max(0, recent.findIndex((b) => b.id === selectedId));
  const next = recent.map((b, i) => {
    const ta = b.title + '\0' + b.author;
    const prev = old.get(b.id);
    if (prev && prev.cover === (b.coverThumbUrl || null) && (b.coverThumbUrl || prev.ta === ta)) {
      old.delete(b.id);
      prev.el.setAttribute('aria-label', b.title);
      return prev;
    }
    const el = document.createElement('div');
    el.className = 'flow-item';
    el.dataset.id = b.id;
    el.setAttribute('role', 'option');
    el.setAttribute('aria-label', b.title);
    el.innerHTML = `<div class="cover">${coverMarkup(b, Math.abs(i - sel) <= 1)}</div>`; // 当前项及左右各 1 项即时加载
    attachLongPress(el, b.id);
    return { id: b.id, el, cover: b.coverThumbUrl || null, ta };
  });
  old.forEach((f) => f.el.remove());
  next.forEach((f, i) => {
    if (flow.children[i] !== f.el) flow.insertBefore(f.el, flow.children[i] || null);
  });
  flowItems = next;
  computeMetrics();
  flowPos = Math.max(0, flowItems.findIndex((f) => f.id === selectedId));
  flow.classList.add('no-anim');
  applyPositions();
  requestAnimationFrame(() => requestAnimationFrame(() => flow.classList.remove('no-anim')));
  infoShownId = null;
  syncSelection();
}

// 选中状态的唯一出口：封面高亮、网格高亮、下方信息全部由 selectedId → 同一个 book 对象得出
let infoShownId = null;
function syncSelection() {
  const b = selectedBook();
  flowItems.forEach(({ id, el }) => {
    const yes = id === selectedId;
    el.setAttribute('aria-selected', String(yes));
  });
  document.querySelectorAll('.grid-book').forEach((el) => el.classList.toggle('selected', el.dataset.id === selectedId));
  const si = flowItems.findIndex((f) => f.id === selectedId);
  for (let k = si - 2; k <= si + 2; k++) { // 初始只保证 ±1 即时；选中变化后顺势预热 ±2，快速拖动不露空白
    const im = flowItems[k] && flowItems[k].el.querySelector('img');
    if (im && im.loading !== 'eager') im.loading = 'eager';
  }
  flow.setAttribute('aria-activedescendant', '');
  renderInfo(b);
  try {
    if (selectedId) sessionStorage.setItem('lnreader:selected', selectedId);
  } catch (_) {}
}
function renderInfo(b) {
  if (!b) {
    info.innerHTML = '';
    infoShownId = null;
    return;
  }
  const pct = pctOf(b);
  // 同一本书只更新进度数字，避免打断按钮点击
  if (infoShownId === b.id && info.querySelector('.progress-num')) {
    info.querySelector('.progress-fill').style.width = pct + '%';
    info.querySelector('.progress-num').textContent = pct + '%';
    return;
  }
  infoShownId = b.id;
  info.dataset.bookId = b.id;
  info.innerHTML = `<div class="flow-book-title">${escapeHTML(b.title)}</div><div class="flow-author">${escapeHTML(b.author)}</div><div class="progress-line"><div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div><span class="progress-num">${pct}%</span></div><button class="primary-btn" id="continueBtn">${b.lastOpenedAt && b.progress > 0 ? '继续阅读' : '开始阅读'}</button>`;
  // 按钮取的是“点击那一刻的 selectedId”，永远是当前中间那本
  $('#continueBtn').addEventListener('click', () => openBook(selectedId));
}
function goTo(index, { animate = true } = {}) {
  if (!flowItems.length) return;
  index = Math.max(0, Math.min(flowItems.length - 1, index));
  if (!animate) flow.classList.add('no-anim');
  flowPos = index;
  applyPositions();
  if (!animate) requestAnimationFrame(() => requestAnimationFrame(() => flow.classList.remove('no-anim')));
  const id = flowItems[index].id;
  if (id !== selectedId) {
    selectedId = id;
    syncSelection();
    buzz(10);
  }
}
const indexOfSelected = () => Math.max(0, flowItems.findIndex((f) => f.id === selectedId));

// --- 拖动 / 滑动 ---
const root = document.documentElement;
let dragEndTimer = 0;
let drag = null;
flow.addEventListener('pointerdown', (e) => {
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  drag = { x: e.clientX, pos0: flowPos, moved: false, samples: [{ x: e.clientX, t: performance.now() }], id: e.pointerId };
});
flow.addEventListener('pointermove', (e) => {
  if (!drag || e.pointerId !== drag.id) return;
  const dx = e.clientX - drag.x;
  if (!drag.moved && Math.abs(dx) > 6) {
    drag.moved = true;
    flow.classList.add('dragging');
    clearTimeout(dragEndTimer);
    root.classList.add('dragging'); // 顶栏临时去掉 backdrop-filter
    try {
      flow.setPointerCapture(e.pointerId);
    } catch (_) {}
  }
  if (!drag.moved) return;
  drag.samples.push({ x: e.clientX, t: performance.now() });
  if (drag.samples.length > 6) drag.samples.shift();
  const max = flowItems.length - 1;
  let pos = drag.pos0 - dx / metrics.d1;
  if (pos < 0) pos *= 0.35; // 到头时有一点阻力
  if (pos > max) pos = max + (pos - max) * 0.35;
  // 拖过两端时给一次更轻的反馈（每次越界只一下，回到范围内才重新计）
  const overshoot = pos < -0.15 || pos > max + 0.15;
  if (overshoot && !drag.edge) buzz(5);
  drag.edge = overshoot;
  flowPos = pos;
  applyPositions();
  // 滑动过程中，信息就跟着“最靠近中心的那一本”实时更新
  const idx = Math.max(0, Math.min(max, Math.round(pos)));
  if (flowItems[idx] && flowItems[idx].id !== selectedId) {
    selectedId = flowItems[idx].id;
    syncSelection();
    buzz(10); // 越过临界点、选中另一本：轻轻一顿
  }
});
function endDrag(e) {
  if (!drag || (e && e.pointerId !== drag.id)) return;
  const d = drag;
  drag = null;
  flow.classList.remove('dragging');
  if (!d.moved) return;
  clearTimeout(dragEndTimer);
  dragEndTimer = setTimeout(() => root.classList.remove('dragging'), 200);
  swallowClick = true;
  setTimeout(() => (swallowClick = false), 0);
  const s = d.samples;
  let v = 0;
  if (s.length >= 2) {
    const a = s[0];
    const b = s[s.length - 1];
    v = (b.x - a.x) / Math.max(1, b.t - a.t); // px/ms
  }
  const startIdx = Math.round(d.pos0);
  let target = Math.round(flowPos);
  if (Math.abs(v) > 0.35 && target === startIdx) target = startIdx + (v < 0 ? 1 : -1); // 快速甩动：至少走一本
  goTo(target);
}
let swallowClick = false;
flow.addEventListener('pointerup', endDrag);
flow.addEventListener('pointercancel', endDrag);
// 点击封面：点侧面的 → 它成为选中并滑到中间；点中间这本 → 打开
flow.addEventListener('click', (e) => {
  if (swallowClick) {
    e.preventDefault();
    return;
  }
  const item = e.target.closest('.flow-item');
  if (!item || item.classList.contains('is-hidden')) return;
  const idx = flowItems.findIndex((f) => f.id === item.dataset.id);
  if (idx < 0) return;
  if (flowItems[idx].id === selectedId) openBook(selectedId);
  else goTo(idx);
});
// 键盘
flow.addEventListener('keydown', (e) => {
  const i = indexOfSelected();
  if (e.key === 'ArrowLeft') goTo(i - 1);
  else if (e.key === 'ArrowRight') goTo(i + 1);
  else if (e.key === 'Home') goTo(0);
  else if (e.key === 'End') goTo(flowItems.length - 1);
  else if (e.key === 'Enter' || e.key === ' ') {
    if (selectedId) openBook(selectedId);
  } else return;
  e.preventDefault();
});
// 触控板 / 鼠标横向滚轮
let wheelAcc = 0;
let wheelLock = 0;
flow.addEventListener(
  'wheel',
  (e) => {
    if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
    e.preventDefault();
    wheelAcc += e.deltaX;
    if (Math.abs(wheelAcc) > 40 && performance.now() > wheelLock) {
      goTo(indexOfSelected() + Math.sign(wheelAcc));
      wheelAcc = 0;
      wheelLock = performance.now() + 220;
    }
  },
  { passive: false }
);
// 保险：任何情况下（聚焦 / scrollIntoView）容器都不允许被横向滚动，否则中心位置会偏
const flowShell = flow.parentElement;
flowShell.addEventListener('scroll', () => (flowShell.scrollLeft = 0));
flow.addEventListener('scroll', () => (flow.scrollLeft = 0));
// 容器宽度变化（旋转屏幕 / 改窗口大小）：按新宽度重新算，选中项仍在正中
new ResizeObserver(() => {
  if (!flowItems.length) return;
  const old = metrics.W;
  computeMetrics();
  if (metrics.W !== old || true) {
    flow.classList.add('no-anim');
    applyPositions();
    requestAnimationFrame(() => requestAnimationFrame(() => flow.classList.remove('no-anim')));
  }
}).observe(flow);

// ============ 书架网格 ============
const gridEls = new Map(); // id -> 已渲染的卡片节点
// 首屏能看到的格子数（超出的封面 loading=lazy）
function gridEagerCount() {
  const top = grid.getBoundingClientRect().top;
  if (top >= innerHeight) return 0;
  const cols = getComputedStyle(grid).gridTemplateColumns.split(' ').length || 3;
  const cardH = (grid.clientWidth / cols) * 1.4 + 44;
  return Math.min(cols * Math.ceil((innerHeight - Math.max(top, 0)) / cardH), 20);
}
function gridCardHTML(b, eager) {
  return `<div class="grid-cover-wrap">${coverMarkup(b, eager)}${!b.lastOpenedAt ? '<span class="new-tag">新</span>' : ''}<span class="progress-tag">${b.finished ? '已读完' : pctOf(b) + '%'}</span>${pctOf(b) > 0 ? `<span class="grid-progress" aria-hidden="true"><i style="width:${pctOf(b)}%"></i></span>` : ''}</div><div class="grid-title">${escapeHTML(b.title)}</div>`;
}
// 复用节点时只更新会变的部分（进度 / 新 / 读完 / 标题），封面 <img> 原样保留
function updateGridEl(el, b) {
  el.classList.toggle('finished', !!b.finished);
  el.setAttribute('aria-label', b.finished ? `${b.title}，已读完` : `${b.title}，${pctOf(b)}%`);
  const wrap = el.querySelector('.grid-cover-wrap');
  const pct = pctOf(b);
  const tag = wrap.querySelector('.progress-tag');
  tag.textContent = b.finished ? '已读完' : pct + '%';
  let bar = wrap.querySelector('.grid-progress');
  if (pct > 0) {
    if (!bar) {
      bar = document.createElement('span');
      bar.className = 'grid-progress';
      bar.setAttribute('aria-hidden', 'true');
      bar.innerHTML = '<i></i>';
      wrap.append(bar);
    }
    bar.firstElementChild.style.width = pct + '%';
  } else if (bar) bar.remove();
  const nt = wrap.querySelector('.new-tag');
  if (!b.lastOpenedAt && !nt) {
    const n = document.createElement('span');
    n.className = 'new-tag';
    n.textContent = '新';
    tag.before(n);
  } else if (b.lastOpenedAt && nt) nt.remove();
  const t = el.querySelector('.grid-title');
  if (t.textContent !== b.title) t.textContent = b.title;
}
function renderGrid() {
  const visible = books.filter((b) => filter === 'all' || b.favorite).sort((a, b) => b.addedAt - a.addedAt);
  if (filter === 'favorite' && !visible.length) {
    grid.innerHTML = '<div class="empty-fav">还没有收藏。长按（电脑上右键）一本书，就能收藏。</div>';
    gridEls.clear();
    return;
  }
  if (grid.firstElementChild && grid.firstElementChild.classList.contains('empty-fav')) grid.replaceChildren();
  const eagerN = gridEagerCount();
  const keep = new Set();
  visible.forEach((b, i) => {
    keep.add(b.id);
    let el = gridEls.get(b.id);
    const ta = b.title + '\0' + b.author;
    if (el && el._cover === (b.coverThumbUrl || null) && (b.coverThumbUrl || el._ta === ta)) {
      updateGridEl(el, b);
    } else {
      if (el) el.remove();
      el = document.createElement('article');
      el.className = 'grid-book' + (b.finished ? ' finished' : '');
      el.dataset.id = b.id;
      el.tabIndex = 0;
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', b.finished ? `${b.title}，已读完` : `${b.title}，${pctOf(b)}%`);
      el.innerHTML = gridCardHTML(b, i < eagerN);
      el._cover = b.coverThumbUrl || null;
      el._ta = ta;
      el.addEventListener('click', () => openBook(b.id));
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openBook(b.id);
        }
      });
      attachLongPress(el, b.id);
      gridEls.set(b.id, el);
    }
    if (grid.children[i] !== el) grid.insertBefore(el, grid.children[i] || null);
  });
  gridEls.forEach((el, id) => {
    if (!keep.has(id)) {
      el.remove();
      gridEls.delete(id);
    }
  });
  document.querySelectorAll('.grid-book').forEach((el) => el.classList.toggle('selected', el.dataset.id === selectedId));
}

// ============ 打开书：真正进入阅读器 ============
async function openBook(id) {
  const b = getBook(id);
  if (!b) return;
  selectedId = id;
  if (!(await Library.hasFile(id))) {
    showToast('这本书的 EPUB 文件不在这台设备上，请重新导入');
    return;
  }
  const ok = await Library.openBook(id); // 记录最近阅读并跳到 reader.html?book=id
  if (!ok) showToast('找不到这本书');
}

// ============ 长按 / 右键菜单 ============
function attachLongPress(el, id) {
  let timer = null;
  let startX = 0;
  let startY = 0;
  let fired = false;
  el.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse') return;
    fired = false;
    startX = e.clientX;
    startY = e.clientY;
    timer = setTimeout(() => {
      fired = true;
      buzz(10);
      showBookMenu(id, e.clientX, e.clientY);
    }, 550);
  });
  el.addEventListener('pointermove', (e) => {
    if (timer && (Math.abs(e.clientX - startX) > 10 || Math.abs(e.clientY - startY) > 10)) {
      clearTimeout(timer);
      timer = null;
    }
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach((t) =>
    el.addEventListener(t, () => {
      clearTimeout(timer);
      timer = null;
    })
  );
  el.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    showBookMenu(id, e.clientX, e.clientY);
  });
  el.addEventListener(
    'click',
    (e) => {
      if (fired) {
        e.preventDefault();
        e.stopImmediatePropagation();
        fired = false;
      }
    },
    { capture: true }
  );
}
function showBookMenu(id, x, y) {
  const b = getBook(id);
  if (!b) return;
  menuBookId = id;
  $('#menuFavorite').textContent = b.favorite ? '取消收藏' : '加入收藏';
  $('#menuFinished').textContent = b.finished ? '标记为未读完' : '标记为读完';
  const menu = $('#bookMenu');
  menu.style.left = Math.min(x, innerWidth - 205) + 'px';
  menu.style.top = Math.min(y, innerHeight - 160) + 'px';
  menu.classList.add('open');
  $('#menuBackdrop').classList.add('open');
}
function closeMenu() {
  $('#bookMenu').classList.remove('open');
  $('#menuBackdrop').classList.remove('open');
  menuBookId = null;
}
$('#menuBackdrop').addEventListener('click', closeMenu);
$('#menuFavorite').addEventListener('click', async () => {
  const b = getBook(menuBookId);
  if (b) {
    await Library.setFavorite(b.id, !b.favorite);
    await refresh();
    showToast(b.favorite ? '已取消收藏' : '已加入收藏');
  }
  closeMenu();
});
$('#menuFinished').addEventListener('click', async () => {
  const b = getBook(menuBookId);
  if (b) {
    await Library.setFinished(b.id, !b.finished);
    await refresh();
    showToast(b.finished ? '已标记为读完' : '已标记为未读完');
  }
  closeMenu();
});
$('#menuRemove').addEventListener('click', async () => {
  const b = getBook(menuBookId);
  if (b && confirm(`确定删除《${b.title}》吗？`)) {
    await Library.removeBook(b.id);
    if (selectedId === b.id) selectedId = null;
    await refresh();
    showToast('已删除');
  }
  closeMenu();
});
document.querySelectorAll('.tab').forEach((btn) =>
  btn.addEventListener('click', () => {
    filter = btn.dataset.filter;
    document.querySelectorAll('.tab').forEach((x) => x.setAttribute('aria-pressed', String(x === btn)));
    renderGrid();
  })
);

// ============ 设置 ============
function openSettings() {
  loadSettings();
  $('#sheetBackdrop').classList.add('open');
  $('#settingsSheet').classList.add('open');
}
function closeSettings() {
  $('#sheetBackdrop').classList.remove('open');
  $('#settingsSheet').classList.remove('open');
}
$('#settingsBtn').addEventListener('click', openSettings);
$('#closeSettings').addEventListener('click', closeSettings);
$('#sheetBackdrop').addEventListener('click', closeSettings);
function setSegment(selector, value) {
  document.querySelectorAll(selector + ' button').forEach((b) => b.classList.toggle('active', b.dataset.value === value));
}
function setTheme(theme) {
  applyThemeSetting(theme);
  setSegment('#themeSegment', theme);
}
function loadSettings() {
  const s = readSettings();
  const a = readAutofit();
  setTheme(readTheme());
  $('#fontSize').value = s.fontSize;
  $('#fontSizeValue').textContent = s.fontSize + 'px';
  setSegment('#pageMode', 'scroll');
  $('#autofitEnabled').checked = a.enabled;
  $('#autofitHeight').value = a.maxHeight;
  $('#autofitHeightValue').textContent = a.maxHeight + '%';
  setSegment('#autofitAlign', a.align);
  $('#autofitGap').value = a.gap;
  $('#autofitGapValue').textContent = a.gap + 'px';
  updateStorageInfo();
}
$('#themeSegment').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-value]');
  if (b) setTheme(b.dataset.value);
});
$('#fontSize').addEventListener('input', (e) => {
  const s = readSettings();
  s.fontSize = +e.target.value;
  writeSettings(s);
  $('#fontSizeValue').textContent = s.fontSize + 'px';
});
$('#pageMode').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-value]');
  if (!b || b.disabled) return;
  const s = readSettings();
  s.pageMode = b.dataset.value;
  writeSettings(s);
  setSegment('#pageMode', s.pageMode);
});
function saveAutofit() {
  writeAutofit({
    enabled: $('#autofitEnabled').checked,
    maxHeight: +$('#autofitHeight').value,
    align: document.querySelector('#autofitAlign .active')?.dataset.value || 'center',
    gap: +$('#autofitGap').value,
  });
}
$('#autofitEnabled').addEventListener('change', saveAutofit);
$('#autofitHeight').addEventListener('input', (e) => {
  $('#autofitHeightValue').textContent = e.target.value + '%';
  saveAutofit();
});
$('#autofitGap').addEventListener('input', (e) => {
  $('#autofitGapValue').textContent = e.target.value + 'px';
  saveAutofit();
});
$('#autofitAlign').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-value]');
  if (!b) return;
  setSegment('#autofitAlign', b.dataset.value);
  saveAutofit();
});
const formatBytes = (n) => (n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB');
async function updateStorageInfo() {
  try {
    const est = await navigator.storage?.estimate?.();
    $('#storageUsage').textContent = est ? formatBytes(est.usage || 0) : '浏览器未提供此信息';
    $('#storageQuota').textContent = est ? '允许 ' + formatBytes(est.quota || 0) : '';
    const p = await navigator.storage?.persisted?.();
    $('#persistStatus').textContent = p ? '已获得持久存储' : '尚未获得持久存储';
  } catch (_) {
    $('#storageUsage').textContent = '暂不可用';
    $('#persistStatus').textContent = '暂不可用';
  }
}
$('#persistBtn').addEventListener('click', async () => {
  try {
    const ok = await navigator.storage?.persist?.();
    $('#persistStatus').textContent = ok ? '已获得持久存储' : '浏览器未授予持久存储';
    showToast(ok ? '持久存储申请成功' : '浏览器暂未授予持久存储');
  } catch (_) {
    showToast('当前浏览器不支持此功能');
  }
});

// 备份：书架元数据 + 阅读进度 + 设置（EPUB 文件本体不包含，体积太大）
$('#exportBackup').addEventListener('click', async () => {
  const { books: list } = await Library.exportData();
  const payload = { app: 'lnreader', version: 2, exportedAt: new Date().toISOString(), books: list, settings: readSettings(), autofit: readAutofit(), theme: readTheme() };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'lnreader-backup-' + new Date().toISOString().slice(0, 10) + '.json';
  a.click();
  URL.revokeObjectURL(a.href);
  showToast('备份已导出（不含 EPUB 文件本身）');
});
$('#importBackup').addEventListener('click', () => $('#backupInput').click());
$('#backupInput').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!Array.isArray(data.books)) throw Error('格式错误');
    if (!confirm('导入备份将替换当前书架的信息，是否继续？\n（备份里不含 EPUB 文件，没有文件的书需要重新导入后才能阅读）')) return;
    await Library.replaceAll(data.books);
    if (data.settings) localStorage.setItem(SETTINGS_KEY, JSON.stringify(data.settings));
    if (data.autofit) localStorage.setItem(AUTOFIT_KEY, JSON.stringify(data.autofit));
    if (data.theme) localStorage.setItem(THEME_KEY, data.theme);
    selectedId = null;
    await refresh();
    loadSettings();
    showToast('备份导入成功');
  } catch (_) {
    showToast('无法读取备份文件');
  } finally {
    e.target.value = '';
  }
});
$('#clearShelf').addEventListener('click', async () => {
  if (confirm('确定清空整个书架吗？此操作无法撤销。')) {
    await Library.clear();
    selectedId = null;
    await refresh();
    showToast('书架已清空');
  }
});

// 示例书：现场生成真正的 EPUB 再导入
async function addSamples() {
  if (books.length && !confirm('载入示例书会将示例书添加到当前书架，是否继续？')) return;
  try {
    showToast('正在生成示例书…', 6000);
    const ill = await (await fetch(import.meta.env.BASE_URL + 'sample/insert01.jpg')).arrayBuffer();
    const now = Date.now();
    let n = 0;
    for (const s of sampleBooks) {
      if (await Library.get(s.id)) continue;
      const buf = await buildSampleEpub(s, ill);
      await Library.addBuffer(buf, {
        existing: new Set(),
        extra: { id: s.id, favorite: !!s.favorite, finished: !!s.finished, progress: s.progress, addedAt: now - s.added * 86400e3, lastOpenedAt: s.ago ? now - s.ago : 0 },
      });
      n++;
    }
    await refresh();
    closeSettings();
    showToast(n ? `示例书已载入（${n} 本）` : '示例书已经在书架里了');
  } catch (err) {
    console.error(err);
    showToast('示例书生成失败');
  }
}
$('#samplesBtn').addEventListener('click', addSamples);
$('#loadSamples').addEventListener('click', addSamples);

// ============ 导入 EPUB ============
// 点击选文件 和 拖拽导入 共用同一个入口：importFileList(files)
const importBtn = $('#importBtn');
const emptyImportBtn = $('#emptyImport');
const importLabel = importBtn.querySelector('.import-label');
const importLabelText = importLabel ? importLabel.textContent : '导入';
const emptyImportText = emptyImportBtn.textContent;
let importing = false;
const isEpub = (f) => /\.epub$/i.test(f.name);
const shortName = (n) => (n.length > 22 ? n.slice(0, 21) + '…' : n);

function setImporting(on, text = '') {
  importing = on;
  [importBtn, emptyImportBtn].forEach((btn) => {
    btn.classList.toggle('loading', on);
    btn.setAttribute('aria-busy', String(on));
  });
  if (importLabel) importLabel.textContent = on ? text : importLabelText;
  emptyImportBtn.textContent = on ? text : emptyImportText;
}

function importSummary(r, rejected) {
  const failed = r.failed + rejected.length;
  const reasons = [...r.details.map((d) => ({ name: d.name, reason: d.reason })), ...rejected.map((f) => ({ name: f.name, reason: '不是 .epub 文件' }))];
  const first = reasons[0];
  if (r.added === 0 && failed === 1 && first) return `导入失败：${shortName(first.name)}，${first.reason}`;
  if (r.added === 0 && failed === 0 && r.skipped) return r.skipped === 1 ? '这本书已经在书架里了' : '这些书都已经在书架里了';
  let msg = `导入完成：新增 ${r.added}`;
  if (r.skipped) msg += `，重复 ${r.skipped}`;
  if (failed) msg += `，失败 ${failed}` + (first ? `（${shortName(first.name)}：${first.reason}）` : '');
  return msg;
}

async function importFileList(fileList) {
  const files = [...fileList];
  if (!files.length) return;
  if (importing) return showToast('正在导入，请稍候…');
  const epubs = files.filter(isEpub);
  const rejected = files.filter((f) => !isEpub(f));
  if (!epubs.length) {
    showToast(files.length === 1 ? `文件类型不对：${shortName(files[0].name)} 不是 .epub` : '文件类型不对：只能导入 .epub 文件', 3200);
    return;
  }
  const total = epubs.length;
  const label = (n) => (total > 1 ? `导入中 ${n}/${total}` : '导入中…');
  setImporting(true, label(1));
  showToast(total > 1 ? `正在导入 1/${total}…` : '正在导入…', 8000);
  try {
    const r = await Library.importFiles(epubs, (p) => {
      const next = Math.min(p.current + 1, total);
      if (p.current < total) {
        setImporting(true, label(next));
        showToast(`正在导入 ${next}/${total}…`, 8000);
      }
    });
    await refresh();
    showToast(importSummary(r, rejected), 4500);
  } catch (err) {
    console.error(err);
    showToast('导入失败：无法读取所选文件');
  } finally {
    setImporting(false);
  }
}

const importClick = () => !importing && $('#epubInput').click();
importBtn.addEventListener('click', importClick);
emptyImportBtn.addEventListener('click', importClick);
$('#epubInput').addEventListener('change', async (e) => {
  const files = [...e.target.files];
  e.target.value = '';
  await importFileList(files);
});

// --- 拖拽导入：把文件拖到页面任意位置，出现很淡的遮罩 + 细虚线框 ---
const dropVeil = document.createElement('div');
dropVeil.className = 'drop-veil';
dropVeil.setAttribute('aria-hidden', 'true');
dropVeil.innerHTML = '<div class="drop-frame"><span>松开以导入</span></div>';
document.body.append(dropVeil);
let dragDepth = 0;
const hasFiles = (e) => !!e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
const hideVeil = () => {
  dragDepth = 0;
  dropVeil.classList.remove('show');
};
window.addEventListener('dragenter', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth++;
  dropVeil.classList.add('show');
});
window.addEventListener('dragover', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault(); // 必须阻止默认行为，浏览器才允许 drop；同时避免浏览器直接打开文件
  e.dataTransfer.dropEffect = 'copy';
});
window.addEventListener('dragleave', (e) => {
  if (!hasFiles(e)) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) dropVeil.classList.remove('show');
});
window.addEventListener('drop', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  hideVeil();
  importFileList(e.dataTransfer.files);
});
window.addEventListener('dragend', hideVeil);
window.addEventListener('blur', hideVeil);

// ============ 刷新与启动 ============
// 同一时刻只跑一次；运行期间再来的请求合并成“再跑一轮”（bfcache 恢复时 pageshow / visibilitychange / storage 会连着触发）
let refreshing = null;
let refreshAgain = false;
function refresh() {
  if (refreshing) {
    refreshAgain = true;
    return refreshing;
  }
  refreshing = (async () => {
    try {
      do {
        refreshAgain = false;
        books = await Library.list();
        render();
      } while (refreshAgain);
    } finally {
      refreshing = null;
    }
  })();
  return refreshing;
}
let changeTimer = 0;
const scheduleRefresh = () => {
  clearTimeout(changeTimer);
  changeTimer = setTimeout(refresh, 150); // 别的标签页边读边存进度时，不要每次都整页重绘
};

// 页面滚动：开始滚动时给根节点加 .is-scrolling（顶栏临时去掉 blur），停止 200ms 后再撤；只在开始 / 结束各切一次类
let scrollTimer = 0;
let isScrolling = false;
window.addEventListener(
  'scroll',
  () => {
    if (!isScrolling) {
      isScrolling = true;
      root.classList.add('is-scrolling');
    }
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      isScrolling = false;
      root.classList.remove('is-scrolling');
    }, 200);
  },
  { passive: true }
);
if (!('ontouchstart' in window) || matchMedia('(display-mode: standalone)').matches === false) $('#installHint').hidden = false;
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeMenu();
    closeSettings();
  }
});
// 从阅读页返回（包括 bfcache 恢复）：重新读取最新进度和最近阅读
window.addEventListener('pageshow', (e) => e.persisted && refresh());
document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && refresh());
onLibraryChange(scheduleRefresh);
refresh();
