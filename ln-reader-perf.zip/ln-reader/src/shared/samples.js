// 示例书：在浏览器里现场生成真正的 EPUB（有封面、目录、多章正文、插图），
// 再走和用户导入完全相同的流程，所以点开每一本看到的都是它自己的内容。

export const sampleBooks = [
  { id: 'sample-1', title: '星之海与旅人的约定', author: '白川透', progress: 0.42, favorite: true, ago: 18 * 60e3, added: 8, hue: 222 },
  { id: 'sample-2', title: '在世界尽头等待春天', author: '水野遥', progress: 0.78, favorite: false, ago: 5 * 3600e3, added: 7, hue: 150 },
  { id: 'sample-3', title: '夏日、蝉鸣与未寄出的信', author: '青木凛', progress: 1, finished: true, favorite: true, ago: 86400e3, added: 6, hue: 28 },
  { id: 'sample-4', title: '魔法师的慢生活', author: '森野小夜', progress: 0.12, favorite: false, ago: 0, added: 5, hue: 280 },
  { id: 'sample-5', title: '第七个雨季', author: '林檎', progress: 0.03, favorite: false, ago: 0, added: 4, hue: 190 },
  { id: 'sample-6', title: '月光邮局', author: '秋山澪', progress: 0.56, favorite: false, ago: 3 * 86400e3, added: 3, hue: 252 },
  { id: 'sample-7', title: '猫与旧书店', author: '三浦春', progress: 0, favorite: false, ago: 0, added: 2, hue: 12 },
  { id: 'sample-8', title: '玻璃海岸线', author: '高桥悠', progress: 0.91, favorite: true, ago: 4 * 86400e3, added: 1, hue: 172 },
  { id: 'sample-9', title: '没有名字的魔女', author: '雾岛', progress: 0, favorite: false, ago: 0, added: 0.5, hue: 330 },
  { id: 'sample-10', title: '远方的灯火', author: '七海', progress: 0.2, favorite: false, ago: 5 * 86400e3, added: 0.04, hue: 44 },
];

const pool = [
  '风从窗缝里挤进来，把桌上的纸页一张张翻开。',
  '她停下脚步，回头望了一眼来时的路，那里已经被薄雾盖住了。',
  '“真的要走吗？”他问，声音比想象中轻。',
  '街灯一盏接一盏地亮起，像有人在远处慢慢数着什么。',
  '那天的天空蓝得有些不真实，云被拉成很长很长的线。',
  '茶已经凉了，但谁也没有伸手去换。',
  '“再等一会儿吧，”她说，“也许下一班车就会来。”',
  '远处传来钟声，一下，两下，直到数不清为止。',
  '他把信折好，放进口袋里，又取出来，再放回去。',
  '雨停了，屋檐上的水珠落在石阶上，发出细碎的声音。',
  '“你相信吗？有些约定，哪怕忘记了，也还是会实现的。”',
  '书页的边缘已经泛黄，却依旧留着淡淡的墨香。',
  '她笑了笑，把到嘴边的话咽了回去，只是轻轻点了点头。',
  '夜里的海很安静，只有潮水一遍遍重复着同一句话。',
  '他忽然明白，所谓旅途，不过是把一个人的影子拉得更长而已。',
  '窗外的樱花开了又落，谁也没有注意到春天已经走远。',
  '“别担心，”他说，“我会在原地等你。”',
  '火车缓缓驶出站台，把熟悉的街道留在了身后。',
  '她把手心贴在玻璃上，凉意一点点渗进来。',
  '风铃响了一声，又一声，像是在回答什么人的呼唤。',
  '路的尽头亮着一盏灯，不知道是谁点的，也不知道会亮到什么时候。',
  '“说好了的。”她小声重复着，仿佛这样就能让它变成真的。',
  '日子像一页页被翻过的书，没有人能停在同一行。',
  '最后一缕阳光落在肩头，温度几乎已经感觉不到了。',
];

function rng(seed) {
  let s = [...seed].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7) || 1;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function coverSvg(b) {
  const h = b.hue;
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="500" height="700" viewBox="0 0 500 700">
<defs><linearGradient id="g" x1="0" y1="0" x2="0.6" y2="1"><stop offset="0" stop-color="hsl(${h} 45% 88%)"/><stop offset="1" stop-color="hsl(${(h + 40) % 360} 40% 70%)"/></linearGradient></defs>
<rect width="500" height="700" fill="url(#g)"/>
<circle cx="360" cy="170" r="70" fill="hsl(${h} 60% 96%)" opacity=".85"/>
<path d="M0 520 Q130 440 260 500 T500 470 V700 H0Z" fill="hsl(${h} 35% 40%)" opacity=".55"/>
<path d="M0 570 Q150 510 300 560 T500 540 V700 H0Z" fill="hsl(${h} 35% 28%)" opacity=".7"/>
<text x="250" y="300" font-family="serif" font-size="${b.title.length > 9 ? 32 : 40}" text-anchor="middle" fill="hsl(${h} 40% 18%)">${esc(b.title.slice(0, 9))}</text>
<text x="250" y="${b.title.length > 9 ? 350 : 0}" font-family="serif" font-size="32" text-anchor="middle" fill="hsl(${h} 40% 18%)">${esc(b.title.slice(9, 18))}</text>
<text x="250" y="420" font-family="sans-serif" font-size="20" text-anchor="middle" fill="hsl(${h} 30% 24%)">${esc(b.author)}</text>
</svg>`;
}

const page = (title, body) => `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="zh"><head><title>${esc(title)}</title></head><body>${body}</body></html>`;

export async function buildSampleEpub(b, illustrationBytes) {
  const rand = rng(b.id);
  const chapters = [];
  const N = 5;
  for (let c = 0; c < N; c++) {
    const paras = [];
    paras.push(`<p>《${esc(b.title)}》 · ${esc(b.author)} 著（示例内容，用来测试阅读器）</p>`);
    const count = 22;
    for (let i = 0; i < count; i++) {
      const a = pool[Math.floor(rand() * pool.length)];
      const bb = pool[Math.floor(rand() * pool.length)];
      paras.push(`<p>${esc(a)}${esc(bb)}</p>`);
      if (c === 1 && i === 5) paras.push(`<div class="illust"><img src="images/insert01.jpg" alt="${esc(b.title)}插图"/></div>`);
      if (c === 2 && i === 3) paras.push(`<p><ruby>轻小说<rt>ライトノベル</rt></ruby>里常见的注音，也能正常显示。</p>`);
    }
    chapters.push({ id: `c${c + 1}`, file: `chapter${c + 1}.xhtml`, title: `第${'一二三四五六七八九十'[c]}章`, body: `<h1>第${'一二三四五六七八九十'[c]}章　${esc(b.title)}</h1>${paras.join('')}` });
  }
  const { default: JSZip } = await import('jszip');
  const zip = new JSZip();
  zip.file('mimetype', 'application/epub+zip', { compression: 'STORE' });
  zip.file('META-INF/container.xml', `<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>`);
  zip.file(
    'OEBPS/content.opf',
    `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="uid">${b.id}</dc:identifier><dc:title>${esc(b.title)}</dc:title><dc:creator>${esc(b.author)}</dc:creator><dc:language>zh</dc:language></metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="cover" href="cover.svg" media-type="image/svg+xml" properties="cover-image"/>
<item id="ill" href="images/insert01.jpg" media-type="image/jpeg"/>
${chapters.map((c) => `<item id="${c.id}" href="${c.file}" media-type="application/xhtml+xml"/>`).join('\n')}
</manifest>
<spine>${chapters.map((c) => `<itemref idref="${c.id}"/>`).join('')}</spine>
</package>`
  );
  zip.file('OEBPS/nav.xhtml', page('目录', `<nav epub:type="toc"><ol>${chapters.map((c) => `<li><a href="${c.file}">${c.title}</a></li>`).join('')}</ol></nav>`));
  zip.file('OEBPS/cover.svg', coverSvg(b));
  zip.file('OEBPS/images/insert01.jpg', illustrationBytes);
  chapters.forEach((c) => zip.file('OEBPS/' + c.file, page(c.title, c.body)));
  return zip.generateAsync({ type: 'arraybuffer' });
}
