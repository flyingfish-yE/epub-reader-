// 书架与阅读器共用的设置（键名沿用 B 的约定，阅读页 Aa 面板与书架设置页读写同一份）
export const SETTINGS_KEY = 'lnreader:settings';
export const AUTOFIT_KEY = 'lnreader:autofit';
export const THEME_KEY = 'lnreader:theme';
export const IMAGE_KEY = 'lnreader-image-overrides'; // A 的插图设置键，保持不变

const safeParse = (s, fallback) => {
  try {
    return JSON.parse(s) || fallback;
  } catch (_) {
    return fallback;
  }
};

// maxHeight 默认 85：对应 A 里原来的 FIT_VIEWPORT = 0.85
export const readSettings = () => ({
  fontSize: 18,
  pageMode: 'scroll',
  ...safeParse(localStorage.getItem(SETTINGS_KEY), {}),
});
export const writeSettings = (s) => localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));

export const readAutofit = () => ({
  enabled: true,
  maxHeight: 85,
  align: 'center',
  gap: 16,
  ...safeParse(localStorage.getItem(AUTOFIT_KEY), {}),
});
export const writeAutofit = (a) => localStorage.setItem(AUTOFIT_KEY, JSON.stringify(a));

export const readTheme = () => localStorage.getItem(THEME_KEY) || 'auto';
export function applyTheme(theme) {
  const dark = theme === 'night' || (theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'night' : 'day';
  return dark ? 'night' : 'day';
}
export function setTheme(theme) {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (_) {}
  return applyTheme(theme);
}

export const readImageOverrides = () => safeParse(localStorage.getItem(IMAGE_KEY), {});
export const writeImageOverrides = (all) => localStorage.setItem(IMAGE_KEY, JSON.stringify(all));
export { safeParse };
