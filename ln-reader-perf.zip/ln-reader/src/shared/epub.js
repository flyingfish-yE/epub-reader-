// 轻量 EPUB 解析：JSZip 解包 → OPF/spine/目录/封面 → 章节清洗成可直接放进阅读器 #reader 的 DOM。
// 不用 iframe：这样 A 的插图缩放 / 捏合 / 圆点拖动可以直接绑在正文 DOM 上。

const XHTML_NS = 'application/xhtml+xml';
const byLocal = (root, name) => [...root.getElementsByTagNameNS('*', name)];
const firstLocal = (root, name) => root.getElementsByTagNameNS('*', name)[0] || null;

function dirname(p) {
  const i = p.lastIndexOf('/');
  return i < 0 ? '' : p.slice(0, i + 1);
}
function safeDecode(s) {
  try {
    return decodeURIComponent(s);
  } catch (_) {
    return s;
  }
}
// 把 href 按 base 所在目录解析成 zip 内的绝对路径（去掉 #片段 和 ?查询）
export function resolvePath(baseFile, href) {
  if (!href) return '';
  href = href.split('#')[0].split('?')[0];
  if (/^[a-z][a-z0-9+.-]*:/i.test(href)) return '';
  const parts = (href.startsWith('/') ? href.slice(1) : dirname(baseFile) + href).split('/');
  const out = [];
  for (const seg of parts) {
    if (seg === '..') out.pop();
    else if (seg && seg !== '.') out.push(seg);
  }
  return safeDecode(out.join('/'));
}

const BLOCK_OK = new Set(
  'p div span br hr h1 h2 h3 h4 h5 h6 em strong b i u s del ins small sub sup ruby rt rp rb blockquote pre code ul ol li dl dt dd table thead tbody tfoot tr td th caption figure figcaption section article aside header footer a img center'.split(
    ' '
  )
);
const DROP = new Set('script style link meta iframe object embed form input button select textarea audio video canvas noscript title head math'.split(' '));

export class EpubBook {
  constructor(zip) {
    this.zip = zip;
    this.lowerIndex = new Map();
    zip.forEach((p) => this.lowerIndex.set(p.toLowerCase(), p));
    this.blobUrls = new Map();
    this.imageInfos = new Map();
    this.meta = { title: '', author: '' };
    this.manifest = new Map();
    this.spine = [];
    this.toc = [];
  }

  findFile(path) {
    if (!path) return null;
    return this.zip.file(path) || this.zip.file(safeDecode(path)) || (this.lowerIndex.has(path.toLowerCase()) ? this.zip.file(this.lowerIndex.get(path.toLowerCase())) : null);
  }
  async readText(path) {
    const f = this.findFile(path);
    return f ? f.async('string') : null;
  }

  // 阅读页启动时提前触发，和读 IndexedDB 并行；书架页只在导入 / 示例书时才会加载
  static preload() {
    return import('jszip').catch(() => {});
  }

  static async open(buffer) {
    const { default: JSZip } = await import('jszip');
    const zip = await JSZip.loadAsync(buffer);
    const book = new EpubBook(zip);
    await book.parse();
    return book;
  }

  async parse() {
    const containerXml = await this.readText('META-INF/container.xml');
    if (!containerXml) throw new Error('不是有效的 EPUB（缺少 container.xml）');
    const cdoc = new DOMParser().parseFromString(containerXml, 'application/xml');
    const rootfile = firstLocal(cdoc, 'rootfile');
    const opfPath = rootfile && rootfile.getAttribute('full-path');
    if (!opfPath) throw new Error('不是有效的 EPUB（找不到 OPF）');
    this.opfPath = opfPath;
    const opfText = await this.readText(opfPath);
    if (!opfText) throw new Error('EPUB 的 OPF 文件缺失');
    const opf = new DOMParser().parseFromString(opfText, 'application/xml');

    // 元数据
    const md = firstLocal(opf, 'metadata');
    const textOf = (name) => {
      const el = md && firstLocal(md, name);
      return el ? el.textContent.trim() : '';
    };
    this.meta.title = textOf('title') || '未命名';
    const creators = md ? byLocal(md, 'creator').map((e) => e.textContent.trim()).filter(Boolean) : [];
    this.meta.author = creators.join(' / ') || '未知作者';

    // manifest
    let coverId = null;
    if (md) {
      for (const m of byLocal(md, 'meta')) if (m.getAttribute('name') === 'cover') coverId = m.getAttribute('content');
    }
    for (const it of byLocal(opf, 'item')) {
      const id = it.getAttribute('id');
      const href = it.getAttribute('href');
      if (!id || !href) continue;
      this.manifest.set(id, {
        id,
        path: resolvePath(opfPath, href),
        mediaType: it.getAttribute('media-type') || '',
        properties: it.getAttribute('properties') || '',
      });
    }
    this.coverItem = null;
    for (const item of this.manifest.values()) if (/\bcover-image\b/.test(item.properties)) this.coverItem = item;
    if (!this.coverItem && coverId && this.manifest.has(coverId)) this.coverItem = this.manifest.get(coverId);

    // spine（只保留正文页）
    const spineEl = firstLocal(opf, 'spine');
    const ncxId = spineEl && spineEl.getAttribute('toc');
    for (const ref of spineEl ? byLocal(spineEl, 'itemref') : []) {
      const item = this.manifest.get(ref.getAttribute('idref'));
      if (!item) continue;
      if (!/html|xml/.test(item.mediaType) || /ncx/.test(item.mediaType)) continue;
      const f = this.findFile(item.path);
      const size = f && f._data && f._data.uncompressedSize ? f._data.uncompressedSize : 0;
      this.spine.push({ ...item, size });
    }
    if (!this.spine.length) throw new Error('EPUB 里没有可阅读的章节');
    // 没有尺寸信息时，每章等权重
    if (this.spine.every((s) => !s.size)) this.spine.forEach((s) => (s.size = 1));
    else this.spine.forEach((s) => (s.size = s.size || 1));
    this.totalSize = this.spine.reduce((a, s) => a + s.size, 0);
    let acc = 0;
    this.spine.forEach((s) => {
      s.start = acc / this.totalSize;
      acc += s.size;
      s.span = s.size / this.totalSize;
    });

    await this.parseToc(ncxId);
  }

  spineIndexOf(path) {
    return this.spine.findIndex((s) => s.path === path || s.path.toLowerCase() === path.toLowerCase());
  }

  async parseToc(ncxId) {
    const entries = [];
    const navItem = [...this.manifest.values()].find((m) => /\bnav\b/.test(m.properties));
    if (navItem) {
      const txt = await this.readText(navItem.path);
      if (txt) {
        const doc = new DOMParser().parseFromString(txt, 'text/html');
        const navs = [...doc.querySelectorAll('nav')];
        const nav = navs.find((n) => /toc/.test(n.getAttribute('epub:type') || '')) || navs[0];
        if (nav) {
          nav.querySelectorAll('a[href]').forEach((a) => {
            let level = 0;
            for (let p = a.parentElement; p && p !== nav; p = p.parentElement) if (p.tagName === 'OL') level++;
            entries.push({ label: a.textContent.trim().replace(/\s+/g, ' '), href: resolvePath(navItem.path, a.getAttribute('href')), frag: (a.getAttribute('href').split('#')[1] || ''), level: Math.max(0, level - 1) });
          });
        }
      }
    }
    if (!entries.length) {
      const ncx = (ncxId && this.manifest.get(ncxId)) || [...this.manifest.values()].find((m) => /ncx/.test(m.mediaType));
      const txt = ncx && (await this.readText(ncx.path));
      if (txt) {
        const doc = new DOMParser().parseFromString(txt, 'application/xml');
        const walk = (parent, level) => {
          for (const np of [...parent.children].filter((c) => c.localName === 'navPoint')) {
            const label = firstLocal(np, 'text');
            const content = [...np.children].find((c) => c.localName === 'content');
            if (label && content) {
              const src = content.getAttribute('src') || '';
              entries.push({ label: label.textContent.trim().replace(/\s+/g, ' '), href: resolvePath(ncx.path, src), frag: src.split('#')[1] || '', level });
            }
            walk(np, level + 1);
          }
        };
        const navMap = firstLocal(doc, 'navMap');
        if (navMap) walk(navMap, 0);
      }
    }
    const toc = [];
    for (const e of entries) {
      const spine = this.spineIndexOf(e.href);
      if (spine >= 0 && e.label) toc.push({ label: e.label, spine, frag: e.frag, level: e.level });
    }
    this.toc = toc.length ? toc : this.spine.map((_, i) => ({ label: `第 ${i + 1} 节`, spine: i, frag: '', level: 0 }));
  }

  // 综合进度（0~1）：按各章字节数加权
  progressOf(spineIndex, ratio) {
    const s = this.spine[Math.max(0, Math.min(this.spine.length - 1, spineIndex))];
    return Math.max(0, Math.min(1, s.start + s.span * Math.max(0, Math.min(1, ratio))));
  }
  // 反过来：由综合进度推出位置（用于只有百分比的书，比如示例书）
  locationOf(progress) {
    const p = Math.max(0, Math.min(1, progress));
    let idx = this.spine.findIndex((s) => p < s.start + s.span);
    if (idx < 0) idx = this.spine.length - 1;
    const s = this.spine[idx];
    return { spine: idx, ratio: s.span ? Math.max(0, Math.min(1, (p - s.start) / s.span)) : 0 };
  }

  async blobUrlFor(path, mediaTypeHint) {
    if (this.blobUrls.has(path)) return this.blobUrls.get(path);
    const f = this.findFile(path);
    if (!f) return null;
    const buf = await f.async('arraybuffer');
    const item = [...this.manifest.values()].find((m) => m.path === path);
    const type = (item && item.mediaType) || mediaTypeHint || guessType(path);
    const url = URL.createObjectURL(new Blob([buf], { type }));
    this.blobUrls.set(path, url);
    return url;
  }

  // 返回 { url, w, h }；宽高从文件头读，读不出来就是 0（调用方退回“等图片 load”的老路径）
  async imageInfo(path) {
    if (this.imageInfos.has(path)) return this.imageInfos.get(path);
    const job = (async () => {
      const f = this.findFile(path);
      if (!f) return null;
      const u8 = await f.async('uint8array');
      const item = [...this.manifest.values()].find((m) => m.path === path);
      const type = (item && item.mediaType) || guessType(path);
      const size = parseImageSize(u8) || { w: 0, h: 0 };
      let url = this.blobUrls.get(path);
      if (!url) {
        url = URL.createObjectURL(new Blob([u8], { type }));
        this.blobUrls.set(path, url);
      }
      return { url, w: size.w, h: size.h };
    })();
    this.imageInfos.set(path, job);
    return job;
  }

  async coverBlob() {
    let path = this.coverItem && this.coverItem.path;
    if (!path) {
      // 没声明封面：用第一章里的第一张图
      const first = await this.loadChapter(0, { forCover: true });
      const img = first && first.querySelector('img[data-epub-src]');
      path = img && img.getAttribute('data-epub-src');
    }
    const f = this.findFile(path);
    if (!f) return null;
    const buf = await f.async('arraybuffer');
    const item = [...this.manifest.values()].find((m) => m.path === path);
    return new Blob([buf], { type: (item && item.mediaType) || guessType(path) });
  }

  // 读取并清洗一章，返回一个 <div>（图片已换成 blob: 地址，除非 forCover）
  async loadChapter(index, opts = {}) {
    const item = this.spine[index];
    const text = await this.readText(item.path);
    if (text == null) throw new Error('章节文件缺失：' + item.path);
    let doc = new DOMParser().parseFromString(text, XHTML_NS);
    if (doc.getElementsByTagName('parsererror').length) doc = new DOMParser().parseFromString(text, 'text/html');
    const body = firstLocal(doc, 'body') || doc.body;
    const root = document.createElement('div');
    root.className = 'chapter-body';
    if (body) for (const child of [...body.childNodes]) this.clean(child, root, item.path);
    if (!opts.forCover && !opts.deferImages) {
      const imgs = [...root.querySelectorAll('img[data-epub-src]')];
      await Promise.all(
        imgs.map(async (img) => {
          const url = await this.blobUrlFor(img.getAttribute('data-epub-src'));
          if (url) img.src = url;
          else img.remove();
        })
      );
    }
    return root;
  }

  clean(node, parent, basePath) {
    if (node.nodeType === 3) {
      parent.appendChild(document.createTextNode(node.nodeValue));
      return;
    }
    if (node.nodeType !== 1) return;
    const name = node.localName.toLowerCase();
    if (DROP.has(name)) return;
    if (name === 'svg') {
      // 封面页常见写法：<svg><image xlink:href="..."/></svg> → 普通 <img>
      const im = firstLocal(node, 'image');
      const href = im && (im.getAttribute('xlink:href') || im.getAttribute('href') || im.getAttributeNS('http://www.w3.org/1999/xlink', 'href'));
      const path = href && resolvePath(basePath, href);
      if (path) {
        const img = document.createElement('img');
        img.setAttribute('data-epub-src', path);
        img.alt = '插图';
        parent.appendChild(img);
      }
      return;
    }
    if (name === 'img') {
      const src = node.getAttribute('src');
      const path = src && resolvePath(basePath, src);
      if (!path) return;
      const img = document.createElement('img');
      img.setAttribute('data-epub-src', path);
      img.alt = node.getAttribute('alt') || '插图';
      parent.appendChild(img);
      return;
    }
    let el;
    if (BLOCK_OK.has(name)) {
      const tag = name === 'center' ? 'div' : name;
      el = document.createElement(tag);
      const id = node.getAttribute('id');
      if (id) el.id = id;
      if (name === 'a') {
        const href = node.getAttribute('href') || '';
        if (/^[a-z][a-z0-9+.-]*:/i.test(href)) {
          if (/^https?:/i.test(href)) {
            el.href = href;
            el.target = '_blank';
            el.rel = 'noopener noreferrer';
          }
        } else if (href) {
          const p = resolvePath(basePath, href);
          const frag = href.includes('#') ? href.split('#')[1] : '';
          if (p) {
            el.setAttribute('data-spine', String(this.spineIndexOf(p)));
            el.setAttribute('data-frag', frag);
          } else if (frag) {
            el.setAttribute('data-spine', 'self');
            el.setAttribute('data-frag', frag);
          }
          el.setAttribute('href', '#');
        }
      }
      if (name === 'td' || name === 'th') {
        ['colspan', 'rowspan'].forEach((a) => node.hasAttribute(a) && el.setAttribute(a, node.getAttribute(a)));
      }
      parent.appendChild(el);
    } else {
      el = parent; // 未知标签：丢掉标签、保留内容
    }
    for (const child of [...node.childNodes]) this.clean(child, el, basePath);
  }

  destroy() {
    this.blobUrls.forEach((u) => URL.revokeObjectURL(u));
    this.blobUrls.clear();
    this.imageInfos.clear();
  }
}

// 只读文件头：PNG / GIF / JPEG / WebP。失败返回 null，不抛错。
export function parseImageSize(u8) {
  try {
    const n = u8.length;
    const be16 = (i) => (u8[i] << 8) | u8[i + 1];
    const le16 = (i) => u8[i] | (u8[i + 1] << 8);
    const le24 = (i) => u8[i] | (u8[i + 1] << 8) | (u8[i + 2] << 16);
    if (n > 24 && u8[0] === 0x89 && u8[1] === 0x50 && u8[2] === 0x4e && u8[3] === 0x47) {
      return { w: ((u8[16] << 24) | (u8[17] << 16) | (u8[18] << 8) | u8[19]) >>> 0, h: ((u8[20] << 24) | (u8[21] << 16) | (u8[22] << 8) | u8[23]) >>> 0 };
    }
    if (n > 10 && u8[0] === 0x47 && u8[1] === 0x49 && u8[2] === 0x46) return { w: le16(6), h: le16(8) };
    if (n > 4 && u8[0] === 0xff && u8[1] === 0xd8) {
      let i = 2;
      while (i + 9 < n) {
        if (u8[i] !== 0xff) {
          i++;
          continue;
        }
        const m = u8[i + 1];
        if (m === 0xff) {
          i++;
          continue;
        }
        if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) {
          i += 2;
          continue;
        }
        if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { w: be16(i + 7), h: be16(i + 5) };
        i += 2 + be16(i + 2);
      }
      return null;
    }
    if (n > 30 && u8[0] === 0x52 && u8[1] === 0x49 && u8[8] === 0x57 && u8[9] === 0x45) {
      const tag = String.fromCharCode(u8[12], u8[13], u8[14], u8[15]);
      if (tag === 'VP8 ') return { w: le16(26) & 0x3fff, h: le16(28) & 0x3fff };
      if (tag === 'VP8L') {
        const b0 = u8[21], b1 = u8[22], b2 = u8[23], b3 = u8[24];
        return { w: 1 + (((b1 & 0x3f) << 8) | b0), h: 1 + (((b3 & 0x0f) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6)) };
      }
      if (tag === 'VP8X') return { w: 1 + le24(24), h: 1 + le24(27) };
    }
  } catch (_) {}
  return null;
}

function guessType(path) {
  const ext = (path.split('.').pop() || '').toLowerCase();
  return { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml' }[ext] || 'application/octet-stream';
}

// 把封面图缩成小缩略图（dataURL），书架用
export async function makeThumb(blob, width = 360) {
  if (!blob) return null;
  const url = URL.createObjectURL(blob);
  try {
    const img = await new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = rej;
      im.src = url;
    });
    const w0 = img.naturalWidth || 500;
    const h0 = img.naturalHeight || 700;
    const w = Math.min(width, w0);
    const h = Math.round((w * h0) / w0);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    return c.toDataURL('image/jpeg', 0.82);
  } catch (_) {
    return null;
  } finally {
    URL.revokeObjectURL(url);
  }
}
