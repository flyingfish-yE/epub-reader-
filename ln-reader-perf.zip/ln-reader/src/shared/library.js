// 书库：书架页和阅读页共用的数据层。
//  - IndexedDB：书的元数据（标题/作者/封面缩略图/收藏…）+ EPUB 二进制
//  - localStorage 'lnreader:state'：阅读位置 / 进度 / 读完 / 最近打开时间（同步写入，pagehide 时也不会丢）
import { EpubBook, makeThumb } from './epub.js';
import { readImageOverrides, writeImageOverrides, safeParse } from './settings.js';

const DB_NAME = 'lnreader';
const STATE_KEY = 'lnreader:state';
export const READER_URL = './reader.html';

let dbPromise = null;
function db() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore('books', { keyPath: 'id' });
        req.result.createObjectStore('files');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}
async function tx(store, mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const t = d.transaction(store, mode);
    const s = Array.isArray(store) ? store.map((n) => t.objectStore(n)) : t.objectStore(store);
    let result;
    Promise.resolve(fn(s, t)).then((r) => (result = r), reject);
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}
const req2p = (r) => new Promise((res, rej) => ((r.onsuccess = () => res(r.result)), (r.onerror = () => rej(r.error))));

// ---------- 阅读状态（同步 localStorage）----------
const readState = () => safeParse(localStorage.getItem(STATE_KEY), {});
const writeState = (st) => {
  try {
    localStorage.setItem(STATE_KEY, JSON.stringify(st));
  } catch (_) {}
};
function patchState(id, patch) {
  const st = readState();
  st[id] = { ...(st[id] || {}), ...patch };
  writeState(st);
  notify();
}

// ---------- 多标签页 / 页面间通知 ----------
const channel = 'BroadcastChannel' in window ? new BroadcastChannel('lnreader') : null;
function notify() {
  try {
    channel && channel.postMessage('changed');
  } catch (_) {}
}
export function onLibraryChange(cb) {
  channel && channel.addEventListener('message', cb);
  window.addEventListener('storage', (e) => e.key === STATE_KEY && cb());
}

const clamp01 = (n) => Math.max(0, Math.min(1, Number(n) || 0));
function merge(rec, st) {
  st = st || {};
  const lastOpenedAt = Math.max(Number(rec.lastOpenedAt) || 0, Number(st.lastOpenedAt) || 0);
  const progress = st.progress != null ? clamp01(st.progress) : clamp01(rec.progress);
  return {
    ...rec,
    title: rec.title || '未命名',
    author: rec.author || '未知作者',
    coverThumbUrl: rec.coverThumbUrl || null,
    addedAt: Number(rec.addedAt) || Date.now(),
    favorite: !!rec.favorite,
    lastOpenedAt,
    progress,
    finished: st.finished != null ? !!st.finished : !!rec.finished,
    position: st.position || rec.position || null,
  };
}

async function allRecords() {
  return tx('books', 'readonly', (s) => req2p(s.getAll()));
}
async function putRecord(rec) {
  const { position, progress, finished, lastOpenedAt, ...stable } = rec; // 这些以 state 为准，但仍保留一份兜底
  await tx('books', 'readwrite', (s) => s.put({ ...stable, progress, finished, lastOpenedAt, position }));
}

function fingerprint(meta, size) {
  return `${meta.title}||${meta.author}||${size}`;
}

// 把导入时的各种底层错误翻成一句清楚的原因（我们自己抛的中文错误原样保留）
function explainImportError(err, file) {
  const msg = String((err && err.message) || err || '');
  if (file && file.size === 0) return '文件是空的';
  if (err && (err.name === 'QuotaExceededError' || /quota/i.test(msg))) return '存储空间不足';
  if (/[\u4e00-\u9fff]/.test(msg)) return msg;
  return '文件损坏或不是有效的 EPUB，无法解析';
}

export const Library = {
  async list() {
    const st = readState();
    return (await allRecords()).map((r) => merge(r, st[r.id]));
  },
  async get(id) {
    const rec = await tx('books', 'readonly', (s) => req2p(s.get(id)));
    return rec ? merge(rec, readState()[id]) : null;
  },
  async getFile(id) {
    return tx('files', 'readonly', (s) => req2p(s.get(id)));
  },

  // 导入真实 EPUB：保存二进制，解析标题 / 作者 / 封面
  async importFiles(files, onProgress) {
    const result = { added: 0, skipped: 0, failed: 0, errors: [], details: [] };
    const existing = new Set((await allRecords()).map((r) => r.fingerprint));
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        if (!/\.epub$/i.test(file.name)) throw new Error('不是 .epub 文件');
        const buffer = await file.arrayBuffer();
        const r = await this.addBuffer(buffer, { fallbackTitle: file.name.replace(/\.epub$/i, ''), existing });
        if (r === 'skipped') result.skipped++;
        else result.added++;
      } catch (err) {
        console.warn('导入失败', file.name, err);
        const reason = explainImportError(err, file);
        result.failed++;
        result.errors.push(`${file.name}：${reason}`);
        result.details.push({ name: file.name, reason });
      }
      onProgress && onProgress({ current: i + 1, total: files.length, name: file.name });
    }
    notify();
    return result;
  },

  // 从 ArrayBuffer 加入书架（真实导入与示例书共用）
  async addBuffer(buffer, { fallbackTitle = '未命名', existing, extra = {} } = {}) {
    const epub = await EpubBook.open(buffer);
    try {
      const meta = { title: epub.meta.title === '未命名' ? fallbackTitle : epub.meta.title, author: epub.meta.author };
      const fp = fingerprint(meta, buffer.byteLength);
      const known = existing || new Set((await allRecords()).map((r) => r.fingerprint));
      if (known.has(fp)) return 'skipped';
      const thumb = await makeThumb(await epub.coverBlob().catch(() => null));
      const id = extra.id || 'book-' + crypto.randomUUID();
      const rec = {
        id,
        ...meta,
        fingerprint: fp,
        coverThumbUrl: thumb,
        addedAt: Date.now(),
        lastOpenedAt: 0,
        progress: 0,
        finished: false,
        favorite: false,
        position: null,
        spineCount: epub.spine.length,
        size: buffer.byteLength,
        ...extra,
      };
      await tx(['books', 'files'], 'readwrite', ([b, f]) => {
        b.put(rec);
        f.put(buffer, id);
      });
      known.add(fp);
      // 示例书带预设进度时，换算成真实阅读位置
      if (extra.progress > 0 && !extra.position) {
        patchState(id, { position: epub.locationOf(extra.progress), progress: extra.progress, finished: !!extra.finished, lastOpenedAt: extra.lastOpenedAt || 0 });
      } else if (extra.lastOpenedAt || extra.finished) {
        patchState(id, { progress: extra.progress || 0, finished: !!extra.finished, lastOpenedAt: extra.lastOpenedAt || 0 });
      }
      return id;
    } finally {
      epub.destroy();
    }
  },

  async removeBook(id) {
    await tx(['books', 'files'], 'readwrite', ([b, f]) => {
      b.delete(id);
      f.delete(id);
    });
    const st = readState();
    delete st[id];
    writeState(st);
    // 同时清掉这本书的插图设置
    const ov = readImageOverrides();
    Object.keys(ov).forEach((k) => k.startsWith(id + '|') && delete ov[k]);
    writeImageOverrides(ov);
    notify();
  },
  async setFavorite(id, value) {
    const rec = await tx('books', 'readonly', (s) => req2p(s.get(id)));
    if (rec) {
      rec.favorite = !!value;
      await tx('books', 'readwrite', (s) => s.put(rec));
      notify();
    }
  },
  async setFinished(id, value) {
    const cur = await this.get(id);
    if (!cur) return;
    const progress = value ? 1 : Math.min(cur.progress, 0.99);
    patchState(id, { finished: !!value, progress });
  },

  // 记录阅读位置（阅读页滚动时同步调用）
  saveProgress(id, { spine, ratio, progress }) {
    const prev = readState()[id] || {};
    let finished = !!prev.finished;
    if (progress >= 0.995) finished = true;
    else if (finished && progress < 0.98) finished = false; // 往回翻了，不再算读完
    patchState(id, { position: { spine, ratio }, progress, finished, lastOpenedAt: Date.now() });
  },

  // 打开一本书：更新“最近阅读”，然后进入阅读页
  async openBook(id) {
    const rec = await this.get(id);
    if (!rec) return false;
    patchState(id, { lastOpenedAt: Date.now() });
    try {
      sessionStorage.setItem('lnreader:selected', id);
    } catch (_) {}
    location.assign(`${READER_URL}?book=${encodeURIComponent(id)}`);
    return true;
  },

  // 备份：元数据 + 阅读状态（EPUB 文件本体不在备份里，体积太大）
  async exportData() {
    return { books: await this.list() };
  },
  async replaceAll(books) {
    await tx('books', 'readwrite', (s) => {
      s.clear();
      books.forEach((b) => s.put({ ...b, fingerprint: b.fingerprint || fingerprint(b, b.size || 0) }));
    });
    const st = {};
    books.forEach((b) => (st[b.id] = { position: b.position || null, progress: b.progress || 0, finished: !!b.finished, lastOpenedAt: b.lastOpenedAt || 0 }));
    writeState(st);
    notify();
  },
  async clear() {
    await tx(['books', 'files'], 'readwrite', ([b, f]) => {
      b.clear();
      f.clear();
    });
    writeState({});
    notify();
  },
  async hasFile(id) {
    const d = await db();
    return new Promise((res) => {
      const r = d.transaction('files').objectStore('files').count(id);
      r.onsuccess = () => res(r.result > 0);
      r.onerror = () => res(false);
    });
  },
};

window.Library = Library;
