// 阅读器：原阅读器（script.js）的全部交互 + EPUB 正文。
// 原来页面上只有“一张”测试图；现在每张 EPUB 插图各自拥有同一套 img-wrap / img-box / 圆点 / 调整面板逻辑，
// 面板（#panel）仍然只有一个，作用于“当前正在调整的那张图”。
import { Library } from '../shared/library.js';
import { EpubBook } from '../shared/epub.js';
import { readSettings, writeSettings, readAutofit, readImageOverrides, writeImageOverrides, setTheme } from '../shared/settings.js';

// ===== 找到页面上的各个元素 =====
const panel = document.getElementById('panel');
const slider = document.getElementById('size-slider');
const sizeValue = document.getElementById('size-value');
const alignButtons = document.querySelectorAll('.align-group button');
const toast = document.getElementById('toast');
const savedInfo = document.getElementById('saved-info');
const fontBtn = document.getElementById('font-btn');
const fontPanel = document.getElementById('font-panel');
const fontSlider = document.getElementById('font-slider');
const fontValue = document.getElementById('font-value');
const reader = document.getElementById('reader');
const chapterEl = document.getElementById('chapter');
const tocBtn = document.getElementById('toc-btn');
const tocPanel = document.getElementById('toc-panel');
const chapterNav = document.getElementById('chapter-nav');
const prevBtn = document.getElementById('prev-chapter');
const nextBtn = document.getElementById('next-chapter');
const indicator = document.getElementById('chapter-indicator');
const editBtnOf = (st) => st.illust.querySelector('.edit-btn');

// ===== 常量 =====
const MIN_PERCENT = 30;
const MAX_PERCENT = 100;

// ===== 数据：一张图的设置 =====
// widthPercent：图片宽度占“这一行”宽度的百分比；高度永远按原比例自动算
// 现在按“书 id | 图片在 EPUB 里的路径”区分不同的图（仍存在 A 原来的 lnreader-image-overrides 里）
function loadSaved(key) {
  try {
    return readImageOverrides()[key] || null;
  } catch (e) {
    return null;
  }
}
function writeSaved(key, cfg) {
  try {
    const all = readImageOverrides();
    if (cfg) all[key] = cfg;
    else delete all[key];
    writeImageOverrides(all);
  } catch (e) {
    console.warn('本地保存失败：', e);
  }
}

const clamp = (v) => Math.max(MIN_PERCENT, Math.min(MAX_PERCENT, Math.round(v)));
const isPortrait = () => window.matchMedia('(orientation: portrait)').matches;
const fitViewport = () => (readAutofit().maxHeight || 85) / 100; // A 里写死 0.85，现在跟随“插图自动适配 · 最大高度”

// 算出“适应屏幕”对应的百分比：让整张图的高度不超过屏幕高度的 N%
let rowWCache = 0; // 批量应用一章插图时临时缓存行宽（同一章每行一样宽），避免每张图都强制排版一次
function fitPercent(st) {
  const rowW = rowWCache || st.wrap.clientWidth;
  const img = st.img;
  const nw = st.nw || img.naturalWidth;
  const nh = st.nh || img.naturalHeight;
  if (!rowW || !nw || !nh) return MAX_PERCENT;
  const aspect = nw / nh;
  return clamp(((window.innerHeight * fitViewport() * aspect) / rowW) * 100);
}
// 没保存过的图用什么默认值：自动适配开着 → 适应屏幕 + 默认对齐；关着 → 占满整行
function defaultConfig(st) {
  const af = readAutofit();
  if (!af.enabled) return { widthPercent: MAX_PERCENT, align: 'center' };
  return { widthPercent: fitPercent(st), align: af.align === 'left' ? 'left' : 'center' };
}

// ===== 每张插图的状态 =====
let bookId = null;
let epub = null;
let active = null; // 当前正在调整的那张图（面板作用的对象）
const illusts = new Set();

const alignNames = { left: '靠左', center: '居中', right: '靠右' };
const describe = (cfg) => cfg.widthPercent + '% · ' + alignNames[cfg.align];

// ===== 把设置应用到图片上 =====
function applyToDom(st) {
  const cfg = st.config;
  st.box.style.width = cfg.widthPercent + '%'; // 只改宽度，高度跟着等比变化
  const map = { left: 'flex-start', center: 'center', right: 'flex-end' };
  st.wrap.style.justifyContent = map[cfg.align];
  st.box.classList.toggle('align-right', cfg.align === 'right');
}
function applyConfig() {
  if (!active) return;
  applyToDom(active);
  const cfg = active.config;
  slider.value = cfg.widthPercent;
  sizeValue.textContent = cfg.widthPercent;
  alignButtons.forEach((btn) => btn.classList.toggle('active', btn.dataset.align === cfg.align));
}
function updateSavedInfo() {
  if (!active) return;
  const s = loadSaved(active.key);
  savedInfo.textContent = s ? '已保存：' + describe(s) + '（存在这台设备的浏览器里）' : '尚未保存（当前为智能默认大小）';
}

// ===== 初始化一张插图：有保存的就用保存的，没有就用“适应屏幕”当默认 =====
function initIllust(st) {
  const s = loadSaved(st.key);
  st.hasSaved = !!s;
  st.config = s ? { widthPercent: clamp(s.widthPercent), align: s.align || 'center' } : defaultConfig(st);
  st.savedConfig = { ...st.config };
  applyToDom(st);
}

// 把正文里的 <img> 变成原阅读器的 img-wrap / img-box / 圆点 / “调整插图”按钮 结构
const HANDLE_SVG =
  '<svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3 11 L11 3 M6 3 H11 V8 M3 6 V11 H8" fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function decorateImages(root) {
  illusts.forEach((st) => !st.illust.isConnected && illusts.delete(st));
  root.querySelectorAll('img[data-epub-src]').forEach((img) => {
    img.draggable = false;
    // 只有它自己的段落（没有别的文字）才算插图；夹在文字里的小图保持行内
    let top = img;
    while (top.parentElement && top.parentElement !== root && top.parentElement.textContent.trim() === '' && top.parentElement.querySelectorAll('img').length === 1) top = top.parentElement;
    const textAround = img.parentElement && img.parentElement !== root && img.parentElement.textContent.trim() !== '';
    if (textAround) {
      img.classList.add('inline-img');
      return;
    }
    const illust = document.createElement('div');
    illust.className = 'illust';
    illust.innerHTML = `<div class="img-wrap"><div class="img-box"><button class="resize-handle" aria-label="拖动缩放图片">${HANDLE_SVG}</button><span class="size-hud" aria-hidden="true"></span></div></div><div class="edit-row"><button class="edit-btn">✎ 调整插图</button></div>`;
    const box = illust.querySelector('.img-box');
    top.replaceWith(illust);
    box.prepend(img);
    const st = { illust, box, hud: illust.querySelector('.size-hud'), wrap: illust.querySelector('.img-wrap'), img, key: `${bookId}|${img.getAttribute('data-epub-src')}`, hasSaved: false, config: { widthPercent: MAX_PERCENT, align: 'center' }, savedConfig: null };
    illust._st = st;
    illust.classList.add('pending'); // 图片还没解出来：先按“最大高度”占位，版面和最终结果接近
    illusts.add(st);
    img.addEventListener('error', () => illust.remove(), { once: true });
  });
}

// 转屏 / 改变窗口大小：没保存过的图，默认大小重新适应屏幕
window.addEventListener('resize', () => {
  illusts.forEach((st) => {
    if (!st.hasSaved && !(active === st && panel.classList.contains('open'))) {
      st.config.widthPercent = defaultConfig(st).widthPercent;
      st.savedConfig = { ...st.config };
      applyToDom(st);
    }
  });
});

// ===== 打开 / 关闭图片面板 =====
// 竖屏时决定面板出现在上方还是下方，尽量不遮住当前这张图：
// 图在上半屏（下方放得下）→ 面板在底部；图在下半屏且上方放得下 → 面板在顶部；都放不下 → 底部 + 把图滚上去
function placePanel(st) {
  panel.classList.remove('panel-top');
  if (!isPortrait()) return 'side'; // 横屏面板在右侧，阅读区会让出位置
  const margin = 12;
  const ph = panel.offsetHeight || window.innerHeight * 0.45;
  const r = st.box.getBoundingClientRect();
  if (r.bottom <= window.innerHeight - ph - margin) return 'bottom';
  if (r.top >= ph + margin && r.bottom <= window.innerHeight - margin) {
    panel.classList.add('panel-top');
    return 'top';
  }
  return 'scroll';
}

function openImagePanel(st) {
  if (active && active !== st) finishEditing(); // 先收起上一张（有改动会自动保存）
  active = st;
  fontPanel.classList.remove('show');
  tocPanel.classList.remove('show');
  const placement = placePanel(st);
  panel.classList.add('open');
  st.img.classList.add('editing');
  st.box.classList.add('editing');
  st.wrap.classList.add('editing');
  document.body.classList.add('editing');
  applyConfig();
  updateSavedInfo();

  // 竖屏且上下都放不下时：面板在底部，把图片滚到屏幕上半部分，免得被面板盖住
  if (placement === 'scroll') {
    setTimeout(() => {
      const top = st.box.getBoundingClientRect().top;
      window.scrollBy({ top: top - 70, behavior: 'smooth' });
    }, 60);
  }
}

function closePanel() {
  panel.classList.remove('open');
  hideHud();
  setScrollLock(false);
  if (active) {
    active.img.classList.remove('editing');
    active.box.classList.remove('editing');
    active.wrap.classList.remove('editing');
  }
  document.body.classList.remove('editing');
  active = null;
}

// 阅读区里的点击：点插图 / 点“调整插图”按钮
reader.addEventListener('click', (e) => {
  const illust = e.target.closest('.illust');
  if (!illust || !illust._st) return;
  if (e.target.closest('.resize-handle')) return;
  if (e.target.closest('.edit-btn') || e.target.closest('.img-box img')) openImagePanel(illust._st);
});

// 保存当前设置（保存按钮、点 ✕、点空白处关闭，都走这里）
function commitSave() {
  if (!active) return;
  active.savedConfig = { ...active.config };
  active.hasSaved = true;
  writeSaved(active.key, active.savedConfig);

  // 这就是以后和队友对接的数据格式
  console.log('保存的设置：', JSON.stringify({ [active.key]: active.savedConfig }));

  toast.textContent = '已保存：' + describe(active.savedConfig);
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 1500);
}

// 关闭面板：改过的话自动保存（所以不用每次都点“保存”）；没改过就直接关
function finishEditing() {
  if (!active) return;
  const changed = active.config.widthPercent !== active.savedConfig.widthPercent || active.config.align !== active.savedConfig.align;
  if (changed) commitSave();
  closePanel();
}

document.getElementById('close-btn').addEventListener('click', finishEditing);

// 点面板和图片以外的任何地方（空白、文字），也会关闭
const inEditor = (t) => active && (panel.contains(t) || active.box.contains(t) || editBtnOf(active).contains(t));
let downInEditor = false;

document.addEventListener('pointerdown', (e) => {
  downInEditor = inEditor(e.target);
});

document.addEventListener('click', (e) => {
  if (!panel.classList.contains('open')) return;
  // 按下或松开在编辑区里（比如拖滑块时手指滑出了面板）都不算“点空白”
  if (downInEditor || inEditor(e.target)) return;
  finishEditing();
});

// ===== 缩放时的实时百分比：显示在图片上方居中，松手后停留一小会儿再淡出 =====
let hudTimer = 0;
let hudSt = null;
function hideHud() {
  clearTimeout(hudTimer);
  if (hudSt) hudSt.hud.classList.remove('show');
  hudSt = null;
}
function scheduleHudHide() {
  clearTimeout(hudTimer);
  hudTimer = setTimeout(hideHud, 900);
}
function showHud() {
  if (!active) return;
  if (hudSt && hudSt !== active) hudSt.hud.classList.remove('show');
  hudSt = active;
  active.hud.textContent = active.config.widthPercent + '%';
  active.hud.classList.add('show');
  clearTimeout(hudTimer);
  if (!drag && !pinch) scheduleHudHide(); // 手还按着就一直显示；滑块 / ± 按钮则停一会儿后淡出
}

// ===== 拖圆点 / 捏合时临时锁住页面滚动（不改 overflow，避免滚动条消失导致重新排版）=====
let scrollLocked = false;
function setScrollLock(on) {
  scrollLocked = on;
  document.body.classList.toggle('gesture-lock', on);
}
const blockWhenLocked = (e) => {
  if (scrollLocked && e.cancelable) e.preventDefault();
};
window.addEventListener('touchmove', blockWhenLocked, { passive: false });
window.addEventListener('wheel', blockWhenLocked, { passive: false });

// ===== 滑块 =====
slider.addEventListener('input', () => {
  if (!active) return;
  active.config.widthPercent = clamp(Number(slider.value));
  applyConfig();
  showHud();
});

// ===== 滑块两边的 − / + ：点一下 ±1%，按住不放会连续变化 =====
function stepPercent(delta) {
  if (!active) return;
  active.config.widthPercent = clamp(active.config.widthPercent + delta);
  applyConfig();
  showHud();
}

function bindStepButton(id, delta) {
  const btn = document.getElementById(id);
  let holdTimer = null;
  let repeatTimer = null;

  const stop = () => {
    clearTimeout(holdTimer);
    clearInterval(repeatTimer);
  };

  btn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    stepPercent(delta); // 先立刻变 1%
    holdTimer = setTimeout(() => {
      repeatTimer = setInterval(() => stepPercent(delta), 70); // 按住 0.4 秒后开始连续变
    }, 400);
  });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => btn.addEventListener(ev, stop));

  // 键盘操作（Tab 选中后按回车/空格）
  btn.addEventListener('click', (e) => {
    if (e.detail === 0) stepPercent(delta);
  });
  btn.addEventListener('contextmenu', (e) => e.preventDefault()); // 手机长按不弹菜单
}

bindStepButton('size-minus', -1);
bindStepButton('size-plus', 1);

// ===== 对齐按钮 =====
alignButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    if (!active) return;
    active.config.align = btn.dataset.align;
    // 图片占满整行时，靠左/靠右看不出区别，所以自动缩小一点
    if (active.config.align !== 'center' && active.config.widthPercent >= MAX_PERCENT) {
      active.config.widthPercent = 70;
    }
    applyConfig();
  });
});

// ===== 适应屏幕 =====
document.getElementById('fit-btn').addEventListener('click', () => {
  if (!active) return;
  active.config = { widthPercent: fitPercent(active), align: 'center' };
  applyConfig();
});

// ===== 恢复默认：清掉保存的设置 =====
document.getElementById('reset-btn').addEventListener('click', () => {
  if (!active) return;
  writeSaved(active.key, null);
  active.hasSaved = false;
  active.config = defaultConfig(active);
  active.savedConfig = { ...active.config };
  applyConfig();
  updateSavedInfo();
});

// ===== 保存按钮 =====
document.getElementById('save-btn').addEventListener('click', () => {
  commitSave();
  closePanel();
});

// ===== 对角线缩放 方式一：拖动角上的圆点 =====
// 原理：把手指移动的 (dx, dy) 换算成“宽度变化量”，
// 因为高度 = 宽度 ÷ 宽高比，所以 dy 对应的宽度变化是 dy × 宽高比，
// 再和 dx 取平均，就是沿对角线拖动的效果。
let drag = null;

reader.addEventListener('pointerdown', (e) => {
  const handle = e.target.closest('.resize-handle');
  if (!handle || !active || !active.box.contains(handle)) return;
  e.preventDefault();
  e.stopPropagation();
  handle.setPointerCapture(e.pointerId);
  setScrollLock(true);
  const r = active.img.getBoundingClientRect();
  drag = {
    x: e.clientX,
    y: e.clientY,
    startPercent: active.config.widthPercent,
    aspect: r.height ? r.width / r.height : 1,
    rowW: active.wrap.clientWidth || 1,
  };
});

reader.addEventListener('pointermove', (e) => {
  if (!drag || !active) return;
  const dx = e.clientX - drag.x;
  const dy = e.clientY - drag.y;
  const sign = active.config.align === 'right' ? -1 : 1; // 靠右时圆点在左下角，往左拖才是放大
  const mult = active.config.align === 'center' ? 2 : 1; // 居中时两边同时长，所以要乘 2 才跟手
  const dw = ((sign * dx + dy * drag.aspect) / 2) * mult;
  active.config.widthPercent = clamp(drag.startPercent + (dw / drag.rowW) * 100);
  applyConfig();
  showHud();
});

const endDrag = () => {
  if (!drag) return;
  drag = null;
  if (!pinch) setScrollLock(false);
  scheduleHudHide();
};
reader.addEventListener('pointerup', endDrag);
reader.addEventListener('pointercancel', endDrag);

// ===== 对角线缩放 方式二：双指捏合（手机 / iPad）=====
const pointers = new Map();
let pinch = null;

reader.addEventListener('pointerdown', (e) => {
  if (!active || !active.box.classList.contains('editing') || !active.box.contains(e.target) || e.target.closest('.resize-handle')) return;
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (pointers.size === 2) {
    const [a, b] = [...pointers.values()];
    pinch = { startDist: Math.hypot(a.x - b.x, a.y - b.y), startPercent: active.config.widthPercent };
    setScrollLock(true);
  }
});

reader.addEventListener('pointermove', (e) => {
  if (!pointers.has(e.pointerId)) return;
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (pinch && pointers.size === 2 && pinch.startDist > 0 && active) {
    const [a, b] = [...pointers.values()];
    const dist = Math.hypot(a.x - b.x, a.y - b.y);
    active.config.widthPercent = clamp(pinch.startPercent * (dist / pinch.startDist));
    applyConfig();
    showHud();
  }
});

const endPinch = (e) => {
  pointers.delete(e.pointerId);
  if (pointers.size < 2 && pinch) {
    pinch = null;
    if (!drag) setScrollLock(false);
    scheduleHudHide();
  }
};
window.addEventListener('pointerup', endPinch);
window.addEventListener('pointercancel', endPinch);

// ===== 导出设置文件 =====
document.getElementById('export-btn').addEventListener('click', () => {
  const pretty = JSON.stringify({ imageOverrides: readImageOverrides() }, null, 2);
  const blob = new Blob([pretty], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'lnreader-image-settings.json';
  a.click();
  URL.revokeObjectURL(a.href);
});

// ===== 日夜切换（和书架共用 lnreader:theme）=====
const themeBtn = document.getElementById('theme-btn');
const syncThemeLabel = () => {
  const isDay = document.documentElement.dataset.theme === 'day';
  themeBtn.textContent = isDay ? '🌙 夜间' : '☀️ 白天';
};
syncThemeLabel();
themeBtn.addEventListener('click', () => {
  const isDay = document.documentElement.dataset.theme === 'day';
  setTheme(isDay ? 'night' : 'day');
  syncThemeLabel();
});

// ===== 文字大小（和书架设置里的“阅读默认值”共用）=====
const savedFont = readSettings().fontSize;
reader.style.fontSize = savedFont + 'px';
fontSlider.value = savedFont;
fontValue.textContent = savedFont;

fontBtn.addEventListener('click', () => {
  tocPanel.classList.remove('show');
  fontPanel.classList.toggle('show');
});

fontSlider.addEventListener('input', () => {
  const ratio = currentRatio(); // 改字号会改变页面高度，先记住读到哪，改完再回到同一处
  reader.style.fontSize = fontSlider.value + 'px';
  fontValue.textContent = fontSlider.value;
  const s = readSettings();
  s.fontSize = Number(fontSlider.value);
  writeSettings(s);
  restoreRatio(ratio);
});

// 点字号 / 目录面板以外的任何地方，面板自动收起
document.addEventListener('click', (e) => {
  if (!fontPanel.contains(e.target) && !fontBtn.contains(e.target)) fontPanel.classList.remove('show');
  if (!tocPanel.contains(e.target) && !tocBtn.contains(e.target)) tocPanel.classList.remove('show');
});

// =====================================================
// 以下是接入 EPUB 的部分
// =====================================================
EpubBook.preload(); // 和读 IndexedDB 并行地把 jszip 拉下来

let current = -1;
let loadToken = 0;
let loading = true;

const perfMark = (n) => {
  try {
    performance.mark('ln:' + n);
  } catch (_) {}
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const idle = window.requestIdleCallback ? (fn) => window.requestIdleCallback(fn, { timeout: 1500 }) : (fn) => setTimeout(fn, 200);

const clamp01 = (n) => Math.max(0, Math.min(1, n));
function currentRatio() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  return max <= 0 ? 0 : clamp01(window.scrollY / max);
}
function restoreRatio(ratio) {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  window.scrollTo(0, max > 0 ? ratio * max : 0);
}

// 用户是否已经自己动手滚过：异步校正位置时，动过就不再“拉”回去
let lastUserInput = 0;
['wheel', 'touchstart', 'pointerdown', 'keydown'].forEach((ev) => window.addEventListener(ev, () => (lastUserInput = performance.now()), { passive: true, capture: true }));

function showStatus(html) {
  chapterEl.innerHTML = `<p class="status">${html}</p>`;
  chapterNav.hidden = true;
}
function setBusy(on) {
  document.body.classList.toggle('is-loading', on);
  chapterNav.classList.toggle('busy', on);
  prevBtn.disabled = on || current <= 0;
  nextBtn.disabled = on || !epub || current >= epub.spine.length - 1;
}

// ---------- 插图：先文本，后图片 ----------
// 每张图：解出 blob + 从文件头读宽高 → 先把宽高写到 <img> 上（版面立刻定型，不用等浏览器解码）→ 再给 src。
// 首屏之外的图 loading=lazy + decoding=async，不会一进章就把整章大图全部解码。
function applyImage(img, info, compensate) {
  const st = img.closest('.illust')?._st;
  if (!info || !info.url) {
    (st ? st.illust : img).remove();
    return;
  }
  const holder = st ? st.illust : img;
  let before = null;
  if (compensate) before = holder.getBoundingClientRect();
  img.decoding = 'async';
  if (info.w && info.h) {
    img.width = info.w;
    img.height = info.h;
    if (st) {
      st.nw = info.w;
      st.nh = info.h;
    }
  }
  if (st) {
    if (info.w && info.h) initIllust(st);
    else {
      img.addEventListener(
        'load',
        () => {
          st.nw = img.naturalWidth;
          st.nh = img.naturalHeight;
          initIllust(st);
        },
        { once: true }
      );
    }
    st.illust.classList.remove('pending');
  }
  img.src = info.url;
  if (before && before.bottom <= 0) {
    // 这张图在视口上方：高度变化会把正文往下推，补偿回来，读的那一行不动（Safari 没有 overflow-anchor）
    const after = holder.getBoundingClientRect();
    if (after.height !== before.height) window.scrollBy(0, after.height - before.height);
  }
}

// 返回 { settled, all }：settled = 预算时间内能拿到的先批量应用；all = 全部完成（后到的逐张应用并做位置补偿）
function loadImages(root, token, budgetMs) {
  const imgs = [...root.querySelectorAll('img[data-epub-src]')];
  if (!imgs.length) return { settled: Promise.resolve(), all: Promise.resolve() };
  const infos = new Array(imgs.length).fill(undefined);
  const done = new Array(imgs.length).fill(false);
  const ph = readAutofit();
  root.style.setProperty('--img-ph', (ph.enabled ? ph.maxHeight : 60) + 'vh');
  let late = false;
  imgs.forEach((img, i) => (img.loading = i < 2 ? 'eager' : 'lazy'));
  const all = Promise.all(
    imgs.map(async (img, i) => {
      let info = null;
      try {
        info = await epub.imageInfo(img.getAttribute('data-epub-src'));
      } catch (_) {}
      if (token !== loadToken) return;
      infos[i] = info;
      if (late) {
        done[i] = true;
        applyImage(img, info, true);
      }
    })
  );
  const settled = Promise.race([all, sleep(budgetMs)]).then(() => {
    if (token !== loadToken) return;
    const first = imgs.find((im) => im.isConnected);
    const w = first && (first.closest('.img-wrap') || first).clientWidth;
    rowWCache = w || 0; // 一次读取
    imgs.forEach((img, i) => {
      if (infos[i] === undefined || done[i]) return;
      done[i] = true;
      applyImage(img, infos[i], false);
    });
    rowWCache = 0;
    late = true;
  });
  return { settled, all };
}

async function showChapter(index, { ratio = 0, frag = '' } = {}) {
  index = Math.max(0, Math.min(epub.spine.length - 1, index));
  flushProgress(); // 切章 / 目录跳转前：把旧章节当前位置立刻存下来
  const token = ++loadToken;
  pendingProgress = null;
  loading = true;
  setBusy(true);
  if (!chapterNav.hidden) indicator.textContent = '加载中…';
  finishEditing();
  perfMark('chapter-start');
  let root;
  try {
    root = await epub.loadChapter(index, { deferImages: true }); // 只出文本，图片稍后
  } catch (err) {
    console.error(err);
    if (token !== loadToken) return;
    showStatus('这一节读取失败：' + (err.message || err));
    loading = false;
    document.body.classList.remove('is-restoring');
    setBusy(false);
    return;
  }
  if (token !== loadToken) return; // 又点了别的章节
  const resuming = ratio > 0 || !!frag;
  current = index;
  // 要恢复到章中间时：先排好版、定好位置再显示，不让人看到“章首 → 跳到中间”
  root.classList.toggle('restoring', resuming);
  document.body.classList.toggle('is-restoring', resuming);
  chapterEl.replaceChildren(root);
  decorateImages(root);
  chapterNav.hidden = false;
  updateNav();
  window.scrollTo(0, 0);
  if (!resuming) requestAnimationFrame(() => perfMark('text-visible'));

  const { settled, all } = loadImages(root, token, resuming ? 1500 : 120); // 恢复到章中间：宁可多等一会儿（此时正文是隐藏的，有提示），也不先显示错位置
  await settled;
  if (token !== loadToken) return;
  // 先按 spine + 章内 ratio 定位
  const target = frag && root.querySelector('#' + CSS.escape(frag));
  if (target) target.scrollIntoView();
  else if (resuming) restoreRatio(ratio);
  root.classList.remove('restoring');
  document.body.classList.remove('is-restoring');
  const revealAt = performance.now();
  loading = false;
  setBusy(false);
  perfMark('positioned');
  flushProgress();
  // 再异步校正：慢图补齐后，如果用户还没动过，就按保存的 ratio 再对一次
  all.then(() => {
    if (token !== loadToken || target || !resuming) return;
    if (lastUserInput < revealAt) restoreRatio(ratio);
  });
}

function markTocCurrent() {
  if (!tocBuilt) return;
  let cur = null;
  tocPanel.querySelectorAll('.toc-item').forEach((b) => {
    b.classList.remove('current');
    if (Number(b.dataset.spine) <= current) cur = b;
  });
  cur && cur.classList.add('current');
}
function updateNav() {
  prevBtn.disabled = current <= 0;
  nextBtn.disabled = current >= epub.spine.length - 1;
  markTocCurrent();
}
function updateIndicator(progress) {
  indicator.textContent = `第 ${current + 1}/${epub.spine.length} 节 · ${Math.round(progress * 100)}%`;
}

// ---------- 阅读进度存盘 ----------
// 滚动：rAF 合帧 + 250ms 时间阈值（连续滚动中每 250ms 最多写一次，停下后补一次）。
// 立即 flush：切后台 / pagehide / beforeunload / freeze / 切章 / 目录跳转 / 返回书架。
// flush 总是用“此刻的真实滚动位置”重新采样，所以后台不触发 rAF 也不会丢。
const SAVE_INTERVAL = 250;
let pendingProgress = null; // { token, spine, ratio, progress }
let lastWriteAt = 0;
let lastWritten = '';
let rafId = 0;
let trailTimer = 0;

function capturePending() {
  if (!epub || loading || current < 0) return null; // 章节还在加载 / 还没定位：此时的滚动位置不是读者的位置
  const ratio = currentRatio();
  pendingProgress = { token: loadToken, spine: current, ratio, progress: epub.progressOf(current, ratio) };
  return pendingProgress;
}
// 幂等 + 防旧结果覆盖：token / 章节不匹配就丢；位置没变就不写
function commitProgress(p) {
  if (!p || loading || p.token !== loadToken || p.spine !== current) return;
  updateIndicator(p.progress);
  const key = p.spine + ':' + p.ratio.toFixed(4);
  pendingProgress = null;
  clearTimeout(trailTimer);
  trailTimer = 0;
  if (key === lastWritten) return;
  lastWritten = key;
  lastWriteAt = performance.now();
  Library.saveProgress(bookId, { spine: p.spine, ratio: p.ratio, progress: p.progress });
}
function flushProgress() {
  cancelAnimationFrame(rafId);
  rafId = 0;
  commitProgress(capturePending());
}
function onScrollTick() {
  rafId = 0;
  if (!capturePending()) return;
  const wait = SAVE_INTERVAL - (performance.now() - lastWriteAt);
  if (wait <= 0) commitProgress(pendingProgress);
  else if (!trailTimer) {
    trailTimer = setTimeout(() => {
      trailTimer = 0;
      commitProgress(capturePending());
    }, wait);
  }
}
window.addEventListener(
  'scroll',
  () => {
    if (loading || rafId) return;
    rafId = requestAnimationFrame(onScrollTick);
  },
  { passive: true }
);
document.addEventListener('visibilitychange', () => document.visibilityState === 'hidden' && flushProgress());
window.addEventListener('pagehide', flushProgress);
window.addEventListener('beforeunload', flushProgress); // 兜底，不是唯一依赖
document.addEventListener('freeze', flushProgress);

prevBtn.addEventListener('click', () => showChapter(current - 1, { ratio: 0 }));
nextBtn.addEventListener('click', () => showChapter(current + 1, { ratio: 0 }));

// 正文里的内部链接（脚注 / 目录跳转）
chapterEl.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-spine]');
  if (!a) return;
  e.preventDefault();
  const sp = a.dataset.spine;
  const frag = a.dataset.frag || '';
  if (sp === 'self') {
    const t = frag && chapterEl.querySelector('#' + CSS.escape(frag));
    t && t.scrollIntoView({ behavior: 'smooth' });
  } else if (Number(sp) >= 0) showChapter(Number(sp), { frag });
});

// 目录：首屏之后再建（几百条按钮不抢首屏），点“目录”时如果还没建好就立刻建
let tocBuilt = false;
function ensureToc() {
  if (tocBuilt || !epub) return;
  tocBuilt = true;
  const frag = document.createDocumentFragment();
  epub.toc.forEach((t) => {
    const b = document.createElement('button');
    b.className = 'toc-item';
    b.textContent = t.label;
    b.dataset.spine = t.spine;
    b.style.paddingLeft = 12 + t.level * 16 + 'px';
    b.addEventListener('click', () => {
      tocPanel.classList.remove('show');
      showChapter(t.spine, { frag: t.frag });
    });
    frag.append(b);
  });
  tocPanel.replaceChildren(frag);
  markTocCurrent();
}
tocBtn.addEventListener('click', () => {
  ensureToc();
  fontPanel.classList.remove('show');
  tocPanel.classList.toggle('show');
  if (tocPanel.classList.contains('show')) tocPanel.querySelector('.current')?.scrollIntoView({ block: 'center' });
});

// ===== 返回书架 =====
document.getElementById('back-btn').addEventListener('click', () => {
  finishEditing();
  flushProgress();
  location.href = './index.html';
});

// ===== 启动：按 ?book=<id> 打开对应那本书 =====
async function init() {
  perfMark('init');
  bookId = new URLSearchParams(location.search).get('book');
  const back = '<a href="./index.html">回到书架</a>';
  if (!bookId) return showStatus('没有指定要打开的书。' + back);
  try {
    const [rec, buf] = await Promise.all([Library.get(bookId), Library.getFile(bookId)]); // 两次 IndexedDB 读取并行
    if (!rec) return showStatus('书架里找不到这本书。' + back);
    if (!buf) return showStatus(`《${rec.title}》的 EPUB 文件不在这台设备上，请回到书架重新导入。` + back);
    document.title = rec.title;
    epub = await EpubBook.open(buf);
    document.documentElement.style.setProperty('--img-gap', readAutofit().gap + 'px');
    // 恢复这本书自己的上次位置；第一次读就从开头
    const pos = rec.position || (rec.progress > 0 ? epub.locationOf(rec.progress) : { spine: 0, ratio: 0 });
    await showChapter(pos.spine, { ratio: pos.ratio });
    idle(ensureToc);
  } catch (err) {
    console.error(err);
    showStatus('打开失败：' + (err.message || err) + '。' + back);
  }
}
init();
